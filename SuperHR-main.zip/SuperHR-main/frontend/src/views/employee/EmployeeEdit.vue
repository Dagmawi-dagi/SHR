<template>
  <div class="employee-edit">
    <div v-if="loading" class="loading-state">
      <div class="loading-spinner"></div>
      <p>{{ $t('common.loading') }}</p>
    </div>

    <div v-else-if="employee" class="detail-wrapper">
      <!-- Header Actions -->
      <div class="action-bar">
        <router-link to="/employees" class="action-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M15 18l-6-6 6-6" />
          </svg>
          {{ $t('common.backToList') }}
        </router-link>
        <div class="action-buttons">
          <button @click="cancelEdit" class="action-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
            {{ $t('common.cancel') }}
          </button>
          <button @click="saveEmployee" class="action-btn primary" :disabled="saving">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
              <polyline points="17 21 17 13 7 13 7 21" />
              <polyline points="7 3 7 8 15 8" />
            </svg>
            {{ saving ? $t('common.saving') : $t('common.saveEmployee') }}
          </button>
        </div>
      </div>

      <!-- Hero Section -->
      <div class="hero-section">
        <div class="hero-left">
          <div class="employee-avatar-large" @click="triggerProfileInput">
            <img
              :src="profilePreview || employee?.profilePictureUrl || getAvatarUrl(employee?.fullName?.trim() || employee?.fullNameEnglish?.trim() || 'Employee')"
              :alt="employee?.fullName?.trim() || 'Employee'"
              @error="handleImageError"
            />
            <div class="avatar-overlay">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
              </svg>
            </div>
          </div>
          <input
            type="file"
            ref="profileInput"
            @change="handleProfileUpload"
            accept="image/jpeg,image/png,image/jpg,image/gif,image/webp"
            style="display: none"
          />
          <div class="employee-basic">
            <div class="edit-name-container">
              <input
                type="text"
                v-model="form.firstName"
                :placeholder="$t('employee.firstName')"
                class="name-input"
                :title="$t('employee.firstName')"
              />
              <input
                type="text"
                v-model="form.middleName"
                :placeholder="$t('employee.middleName')"
                class="name-input"
                :title="$t('employee.middleName')"
              />
              <input
                type="text"
                v-model="form.lastName"
                :placeholder="$t('employee.lastName')"
                class="name-input"
                :title="$t('employee.lastName')"
              />
            </div>
            <div class="employee-tags">
              <span class="tag">{{ getPositionName }}</span>
              <span class="tag">{{ getDepartmentName }}</span>
            </div>
          </div>
        </div>
        <div class="hero-right">
          <div class="employee-code">
            <span class="code-label">{{ $t('common.employeeId') }}</span>
            <strong class="code-value">{{ employee.employeeId }}</strong>
          </div>
          <select v-model="form.status" class="status-select" :class="form.status">
            <option value="active">{{ $t('employee.active') }}</option>
            <option value="on-leave">{{ $t('employee.onLeave') }}</option>
            <option value="terminated">{{ $t('employee.terminated') }}</option>
          </select>
        </div>
      </div>

      <!-- Stats Cards -->
      <div class="stats-cards">
        <div class="stat-card">
          <div class="stat-card-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
              <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
            </svg>
          </div>
          <div class="stat-card-info">
            <span class="stat-label">{{ $t('employee.department') }}</span>
            <span class="stat-number">{{ getDepartmentName }}</span>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          </div>
          <div class="stat-card-info">
            <span class="stat-label">{{ $t('employee.hireDate') }}</span>
            <span class="stat-number">{{ form.hireDateEC || '—' }}</span>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
            </svg>
          </div>
          <div class="stat-card-info">
            <span class="stat-label">{{ $t('employee.employmentType') }}</span>
            <span class="stat-number">{{ getEmploymentTypeLabel(form.employmentType) }}</span>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 8c-3.31 0-6 2.69-6 6 0 3.31 2.69 6 6 6 3.31 0 6-2.69 6-6 0-3.31-2.69-6-6-6z" />
              <path d="M12 2v2M22 12h-2M4 12H2M12 22v2" />
            </svg>
          </div>
          <div class="stat-card-info">
            <span class="stat-label">{{ $t('employee.basicSalary') }}</span>
            <span class="stat-number">{{
              form.basicSalary
                ? `${$t('payroll.basicSalary')} ${Number(form.basicSalary).toLocaleString()}`
                : "—"
            }}</span>
          </div>
        </div>
      </div>

      <!-- Main Content Grid -->
      <div class="content-grid">
        <!-- Left Column -->
        <div class="left-column">
          <!-- Personal Info Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </div>
              <h3>{{ $t('employee.personalInfo') }}</h3>
            </div>
            <div class="info-list">
             <!-- Full Name - Editable -->
<div class="info-item">
  <span class="info-label">
    {{ $t('employee.fullName') }}
    <span class="required">*</span>
  </span>
  <div class="info-value">
    <input 
      type="text" 
      v-model="form.fullNameEnglish" 
      :placeholder="$t('employee.fullNamePlaceholder') || 'Enter full name'"
      :title="$t('employee.fullName')"
    />
  </div>
</div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.workEmail') }}</span>
                <div class="info-value">
                  <input type="email" v-model="form.email" :placeholder="$t('employee.workEmail')" :title="$t('employee.workEmail')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.personalEmail') }}</span>
                <div class="info-value">
                  <input type="email" v-model="form.personalEmail" :placeholder="$t('employee.personalEmail')" :title="$t('employee.personalEmail')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.phone') }}</span>
                <div class="info-value">
                  <input type="tel" v-model="form.phone" :placeholder="$t('employee.phone')" :title="$t('employee.phone')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.dateOfBirth') }}</span>
                <div class="info-value">
                  <input
                    type="text"
                    v-model="form.dateOfBirthEC"
                    placeholder="DD/MM/YYYY"
                    class="ec-date-input"
                    :title="$t('employee.dateOfBirth')"
                  />
                  <small class="ec-hint">Ethiopian Calendar (DD/MM/YYYY)</small>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.gender') }}</span>
                <div class="info-value">
                  <select v-model="form.gender" :title="$t('employee.gender')">
                    <option value="">{{ $t('common.select') }}</option>
                    <option value="male">{{ $t('employee.male') }}</option>
                    <option value="female">{{ $t('employee.female') }}</option>
                    <option value="other">{{ $t('employee.other') }}</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.maritalStatus') }}</span>
                <div class="info-value">
                  <select v-model="form.maritalStatus" :title="$t('employee.maritalStatus')">
                    <option value="">{{ $t('common.select') }}</option>
                    <option value="single">{{ $t('employee.single') }}</option>
                    <option value="married">{{ $t('employee.married') }}</option>
                    <option value="divorced">{{ $t('employee.divorced') }}</option>
                    <option value="widowed">{{ $t('employee.widowed') }}</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.nationality') }}</span>
                <div class="info-value">
                  <select v-model="form.nationality" :title="$t('employee.nationality')">
                    <option value="">{{ $t('common.select') }}</option>
                    <option value="Ethiopian">{{ $t('nationality.ethiopian') }}</option>
                    <option value="American">{{ $t('nationality.american') }}</option>
                    <option value="British">{{ $t('nationality.british') }}</option>
                    <option value="Canadian">{{ $t('nationality.canadian') }}</option>
                    <option value="Australian">{{ $t('nationality.australian') }}</option>
                    <option value="German">{{ $t('nationality.german') }}</option>
                    <option value="French">{{ $t('nationality.french') }}</option>
                    <option value="Italian">{{ $t('nationality.italian') }}</option>
                    <option value="Spanish">{{ $t('nationality.spanish') }}</option>
                    <option value="Kenyan">{{ $t('nationality.kenyan') }}</option>
                    <option value="Eritrean">{{ $t('nationality.eritrean') }}</option>
                    <option value="Somali">{{ $t('nationality.somali') }}</option>
                    <option value="Sudanese">{{ $t('nationality.sudanese') }}</option>
                    <option value="Other">{{ $t('nationality.other') }}</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.nationalId') }}</span>
                <div class="info-value">
                  <div style="display: flex; gap: 8px; align-items: center">
                    <input type="text" v-model="form.nationalId" :placeholder="$t('employee.nationalId')" :title="$t('employee.nationalId')" style="flex: 2" />
                    <button type="button" class="upload-small-btn" @click="triggerNationalIdUpload" :title="$t('upload.title')">
                      {{ nationalIdFile ? $t('common.edit') : $t('common.upload') }}
                    </button>
                    <a v-if="getDocumentUrl('national_id')" :href="getDocumentUrl('national_id')" target="_blank" class="file-link-inline">📄 {{ $t('common.view') }}</a>
                  </div>
                  <input type="file" ref="nationalIdInput" @change="handleNationalIdSelect" accept=".pdf,.jpg,.jpeg,.png" style="display: none" />
                  <small v-if="nationalIdFile" class="field-hint success">{{ $t('employee.fileSelected') }}: {{ nationalIdFile.name }}</small>
                </div>
              </div>
            </div>
          </div>

          <!-- Birth Place Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </div>
              <h3>{{ $t('employee.birthPlace') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('address.region') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.birthPlace.region" :placeholder="$t('address.region')" :title="$t('address.region')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.city') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.birthPlace.city" :placeholder="$t('address.city')" :title="$t('address.city')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.subcity') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.birthPlace.subcity" :placeholder="$t('address.subcity')" :title="$t('address.subcity')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.district') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.birthPlace.district" :placeholder="$t('address.district')" :title="$t('address.district')" />
                </div>
              </div>
            </div>
          </div>

          <!-- Current Company Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                </svg>
              </div>
              <h3>{{ $t('company.currentCompany') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('company.name') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentCompany.companyName" :placeholder="$t('company.namePlaceholder')" :title="$t('company.name')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('company.tin') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentCompany.companyTin" :placeholder="$t('company.tinPlaceholder')" :title="$t('company.tin')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('company.phone') }}</span>
                <div class="info-value">
                  <input type="tel" v-model="form.currentCompany.companyPhone" :placeholder="$t('company.phone')" :title="$t('company.phone')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('company.email') }}</span>
                <div class="info-value">
                  <input type="email" v-model="form.currentCompany.companyEmail" :placeholder="$t('company.email')" :title="$t('company.email')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('company.address') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentCompany.companyAddress" :placeholder="$t('company.addressPlaceholder')" :title="$t('company.address')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('company.poBox') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentCompany.poBox" :placeholder="$t('company.poBoxPlaceholder')" :title="$t('company.poBox')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('company.website') }}</span>
                <div class="info-value">
                  <input type="url" v-model="form.currentCompany.website" placeholder="https://www.company.com" :title="$t('company.website')" />
                </div>
              </div>
            </div>
          </div>

          <!-- Current Address Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 2c-4.42 0-8 3.58-8 8 0 5.5 8 12 8 12s8-6.5 8-12c0-4.42-3.58-8-8-8z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </div>
              <h3>{{ $t('address.currentAddress') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('address.region') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentAddress.region" :placeholder="$t('address.region')" :title="$t('address.region')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.subcity') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentAddress.subcity" :placeholder="$t('address.subcity')" :title="$t('address.subcity')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.kebele') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentAddress.kebele" :placeholder="$t('address.kebele')" :title="$t('address.kebele')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.district') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentAddress.district" :placeholder="$t('address.district')" :title="$t('address.district')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.poBox') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentAddress.poBox" :placeholder="$t('address.poBox')" :title="$t('address.poBox')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.houseNumber') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.currentAddress.houseNumber" :placeholder="$t('address.houseNumber')" :title="$t('address.houseNumber')" />
                </div>
              </div>
            </div>
          </div>

          <!-- Permanent Address Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 2c-4.42 0-8 3.58-8 8 0 5.5 8 12 8 12s8-6.5 8-12c0-4.42-3.58-8-8-8z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </div>
              <h3>{{ $t('address.permanentAddress') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('address.region') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.permanentAddress.region" :placeholder="$t('address.region')" :title="$t('address.region')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.subcity') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.permanentAddress.subcity" :placeholder="$t('address.subcity')" :title="$t('address.subcity')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.kebele') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.permanentAddress.kebele" :placeholder="$t('address.kebele')" :title="$t('address.kebele')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.district') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.permanentAddress.district" :placeholder="$t('address.district')" :title="$t('address.district')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.poBox') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.permanentAddress.poBox" :placeholder="$t('address.poBox')" :title="$t('address.poBox')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.houseNumber') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.permanentAddress.houseNumber" :placeholder="$t('address.houseNumber')" :title="$t('address.houseNumber')" />
                </div>
              </div>
            </div>
          </div>

          <!-- Emergency Contact Card -->
          <div class="info-card emergency-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                  <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                </svg>
              </div>
              <h3>{{ $t('family.emergencyContact') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('family.contactName') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.emergencyContact.name" :placeholder="$t('family.contactNamePlaceholder')" :title="$t('family.contactName')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('family.relationship') }}</span>
                <div class="info-value">
                  <select v-model="form.emergencyContact.relationship" :title="$t('family.relationship')">
                    <option value="">{{ $t('common.select') }}</option>
                    <option value="Spouse">{{ $t('family.spouse') }}</option>
                    <option value="Parent">{{ $t('family.parent') }}</option>
                    <option value="Child">{{ $t('family.child') }}</option>
                    <option value="Sibling">{{ $t('family.sibling') }}</option>
                    <option value="Relative">{{ $t('family.relative') }}</option>
                    <option value="Friend">{{ $t('family.friend') }}</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('family.phoneNumber') }}</span>
                <div class="info-value">
                  <input type="tel" v-model="form.emergencyContact.phone" :placeholder="$t('family.phoneNumber')" :title="$t('family.phoneNumber')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('family.alternatePhone') }}</span>
                <div class="info-value">
                  <input type="tel" v-model="form.emergencyContact.alternatePhone" :placeholder="$t('family.alternatePhonePlaceholder')" :title="$t('family.alternatePhone')" />
                </div>
              </div>
            </div>
          </div>

          <!-- Emergency Contact Address Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 2c-4.42 0-8 3.58-8 8 0 5.5 8 12 8 12s8-6.5 8-12c0-4.42-3.58-8-8-8z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </div>
              <h3>{{ $t('family.emergencyAddress') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('address.city') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.emergencyContactAddress.city" :placeholder="$t('address.city')" :title="$t('address.city')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.subcity') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.emergencyContactAddress.subcity" :placeholder="$t('address.subcity')" :title="$t('address.subcity')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.district') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.emergencyContactAddress.district" :placeholder="$t('address.district')" :title="$t('address.district')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('address.kebele') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.emergencyContactAddress.kebele" :placeholder="$t('address.kebele')" :title="$t('address.kebele')" />
                </div>
              </div>
            </div>
          </div>

          <!-- Education Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M22 10v6M2 10l10-5 10-5-10 5z" />
                  <path d="M6 12v5c3 3 9 3 12 0v-5" />
                </svg>
              </div>
              <h3>{{ $t('education.title') }} ({{ form.education.length }})</h3>
            </div>
            <div class="education-list-edit">
              <div v-for="(edu, idx) in form.education" :key="idx" class="education-edit-item">
                <div class="edit-header">
                  <strong>{{ $t('education.education') }} {{ idx + 1 }}</strong>
                  <button class="remove-btn" @click="removeEducation(idx)">{{ $t('common.remove') }}</button>
                </div>
                <div class="edit-fields">
                  <select v-model="edu.level" :title="$t('education.level')">
                    <option value="">{{ $t('common.select') }}</option>
                    <option value="primary">{{ $t('education.primary') }}</option>
                    <option value="secondary">{{ $t('education.secondary') }}</option>
                    <option value="diploma">{{ $t('education.diploma') }}</option>
                    <option value="bachelor">{{ $t('education.bachelor') }}</option>
                    <option value="master">{{ $t('education.master') }}</option>
                    <option value="phd">{{ $t('education.phd') }}</option>
                    <option value="certificate">{{ $t('education.certificate') }}</option>
                  </select>
                  <input type="text" v-model="edu.institutionName" :placeholder="$t('education.institutionPlaceholder')" :title="$t('education.institutionName')" />
                  <input type="text" v-model="edu.institutionAddress" :placeholder="$t('education.institutionAddress')" :title="$t('education.institutionAddress')" />
                  <div class="date-group">
                    <input type="text" v-model="edu.startDateEC" placeholder="DD/MM/YYYY" class="ec-date-input" :title="$t('education.startDate')" />
                    <input type="text" v-model="edu.endDateEC" placeholder="DD/MM/YYYY" class="ec-date-input" :title="$t('education.endDate')" />
                  </div>
                  <label>
                    <input type="checkbox" v-model="edu.isCurrent" />
                    {{ $t('education.currentlyStudying') }}
                  </label>
                </div>
                <div class="edit-actions">
                  <button class="upload-small-btn" @click="triggerEducationUpload(idx)" :title="$t('upload.title')">📄 {{ $t('common.upload') }}</button>
                </div>
              </div>
              <button class="add-btn" @click="addEducation">+ {{ $t('common.add') }} {{ $t('education.education') }}</button>
            </div>
          </div>

          <!-- Training Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                </svg>
              </div>
              <h3>{{ $t('training.title') }} ({{ form.training.length }})</h3>
            </div>
            <div class="training-list-edit">
              <div v-for="(train, idx) in form.training" :key="idx" class="training-edit-item">
                <div class="edit-header">
                  <strong>{{ $t('training.training') }} {{ idx + 1 }}</strong>
                  <button class="remove-btn" @click="removeTraining(idx)">{{ $t('common.remove') }}</button>
                </div>
                <div class="edit-fields">
                  <input type="text" v-model="train.trainingName" :placeholder="$t('training.trainingNamePlaceholder')" :title="$t('training.trainingName')" />
                  <input type="text" v-model="train.institutionName" :placeholder="$t('training.institutionPlaceholder')" :title="$t('training.institution')" />
                  <input type="text" v-model="train.institutionAddress" :placeholder="$t('training.institutionAddress')" :title="$t('training.institutionAddress')" />
                  <div class="date-group">
                    <input type="text" v-model="train.startDateEC" placeholder="DD/MM/YYYY" class="ec-date-input" :title="$t('training.startDate')" />
                    <input type="text" v-model="train.endDateEC" placeholder="DD/MM/YYYY" class="ec-date-input" :title="$t('training.endDate')" />
                  </div>
                </div>
                <div class="edit-actions">
                  <button class="upload-small-btn" @click="triggerTrainingUpload(idx)" :title="$t('upload.title')">📄 {{ $t('common.upload') }}</button>
                </div>
              </div>
              <button class="add-btn" @click="addTraining">+ {{ $t('common.add') }} {{ $t('training.training') }}</button>
            </div>
          </div>

          <!-- Bank Account Card -->
          <div class="info-card bank-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 2v20M17 7H7M17 17H7M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" />
                </svg>
              </div>
              <h3>{{ $t('bank.title') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('bank.bankName') }}</span>
                <div class="info-value">
                  <select v-model="form.bankAccount.bankName" :title="$t('bank.bankName')">
                    <option value="">{{ $t('common.selectBank') }}</option>
                    <option value="Commercial Bank of Ethiopia">Commercial Bank of Ethiopia (CBE)</option>
                    <option value="Awash Bank">Awash Bank</option>
                    <option value="Dashen Bank">Dashen Bank</option>
                    <option value="United Bank">United Bank</option>
                    <option value="Nib International Bank">Nib International Bank</option>
                    <option value="Hibret Bank">Hibret Bank</option>
                    <option value="Wegagen Bank">Wegagen Bank</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('bank.accountNumber') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.bankAccount.accountNumber" :placeholder="$t('bank.accountNumber')" :title="$t('bank.accountNumber')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('bank.accountHolderName') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.bankAccount.accountHolderName" :placeholder="$t('bank.accountHolderPlaceholder')" :title="$t('bank.accountHolderName')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('bank.branch') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.bankAccount.branch" :placeholder="$t('bank.branchPlaceholder')" :title="$t('bank.branch')" />
                </div>
              </div>
            </div>
          </div>

          <!-- Nationality Acquisition Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M3 21h18M3 10h18M5 6h14M8 3l-2 3h12l-2-3" />
                </svg>
              </div>
              <h3>{{ $t('nationality.title') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('nationality.type') }}</span>
                <div class="info-value">
                  <select v-model="form.nationalityAcquisition.type" :title="$t('nationality.type')">
                    <option value="by_birth">{{ $t('nationality.byBirth') }}</option>
                    <option value="by_law">{{ $t('nationality.byLaw') }}</option>
                    <option value="ethiopian_birth">{{ $t('nationality.ethiopianBirth') }}</option>
                  </select>
                </div>
              </div>
              <div class="info-item" v-if="form.nationalityAcquisition.type === 'by_law'">
                <span class="info-label">{{ $t('nationality.naturalizationCert') }}</span>
                <div class="info-value">
                  <div style="display: flex; gap: 8px">
                    <button type="button" class="upload-small-btn" @click="triggerNaturalizationUpload" :title="$t('upload.title')">
                      {{ nationalityDocFile ? $t('common.edit') : $t('common.upload') }}
                    </button>
                    <a v-if="getDocumentUrl('naturalization_certificate')" :href="getDocumentUrl('naturalization_certificate')" target="_blank" class="file-link-inline">📄 {{ $t('common.view') }}</a>
                  </div>
                  <input type="file" ref="naturalizationInput" @change="handleNaturalizationSelect" accept=".pdf,.jpg,.jpeg,.png" style="display: none" />
                  <small v-if="nationalityDocFile" class="field-hint success">{{ $t('employee.fileSelected') }}: {{ nationalityDocFile.name }}</small>
                </div>
              </div>
            </div>
          </div>

          <!-- Health & Legal Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
                  <path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" />
                </svg>
              </div>
              <h3>{{ $t('healthLegal.title') }}</h3>
            </div>
            <div class="health-legal-content">
              <div class="health-section">
                <h4>{{ $t('healthLegal.healthTitle') }}</h4>
                <label>
                  <input type="checkbox" v-model="form.healthInfo.hasPhysicalInjury" />
                  {{ $t('healthLegal.hasInjury') }}
                </label>
                <textarea v-if="form.healthInfo.hasPhysicalInjury" v-model="form.healthInfo.injuryDescription" :placeholder="$t('healthLegal.injuryPlaceholder')" rows="2" :title="$t('healthLegal.injuryDescription')"></textarea>
              </div>
              <div class="legal-section">
                <h4>{{ $t('healthLegal.legalTitle') }}</h4>
                <label>
                  <input type="checkbox" v-model="form.legalInfo.hasCriminalRecord" />
                  {{ $t('healthLegal.hasCriminalRecord') }}
                </label>
                <textarea v-if="form.legalInfo.hasCriminalRecord" v-model="form.legalInfo.criminalRecordDescription" :placeholder="$t('healthLegal.criminalPlaceholder')" rows="2" :title="$t('healthLegal.criminalDescription')"></textarea>
              </div>
            </div>
          </div>

          <!-- Language Skills Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M5 8h10M9 4v4M11 12h8M15 8v4" />
                  <path d="M2 2h20v20H2z" />
                </svg>
              </div>
              <h3>{{ $t('skills.languageTitle') }}</h3>
            </div>
            <div class="skills-list">
              <div v-for="(lang, idx) in form.languageSkills" :key="idx" class="skill-tag" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                <select v-model="lang.language" style="width: 160px" :title="$t('skills.selectLanguage')">
                  <option value="">{{ $t('skills.selectLanguage') }}</option>
                  <optgroup :label="$t('skills.ethiopianLanguages')">
                    <option value="Amharic">{{ $t('skills.amharic') }}</option>
                    <option value="Oromo">{{ $t('skills.oromo') }}</option>
                    <option value="Tigrinya">{{ $t('skills.tigrinya') }}</option>
                    <option value="Somali">{{ $t('skills.somali') }}</option>
                    <option value="Sidamo">{{ $t('skills.sidamo') }}</option>
                    <option value="Wolaytta">{{ $t('skills.wolaytta') }}</option>
                    <option value="Afar">{{ $t('skills.afar') }}</option>
                    <option value="Hadiyya">{{ $t('skills.hadiyya') }}</option>
                    <option value="Gamo">{{ $t('skills.gamo') }}</option>
                    <option value="Gurage">{{ $t('skills.gurage') }}</option>
                    <option value="Kembata">{{ $t('skills.kembata') }}</option>
                    <option value="Silt'e">{{ $t('skills.silte') }}</option>
                  </optgroup>
                  <optgroup :label="$t('skills.africanLanguages')">
                    <option value="Swahili">{{ $t('skills.swahili') }}</option>
                    <option value="Hausa">{{ $t('skills.hausa') }}</option>
                    <option value="Yoruba">{{ $t('skills.yoruba') }}</option>
                    <option value="Zulu">{{ $t('skills.zulu') }}</option>
                  </optgroup>
                  <optgroup :label="$t('skills.europeanLanguages')">
                    <option value="English">{{ $t('skills.english') }}</option>
                    <option value="French">{{ $t('skills.french') }}</option>
                    <option value="Spanish">{{ $t('skills.spanish') }}</option>
                    <option value="German">{{ $t('skills.german') }}</option>
                    <option value="Italian">{{ $t('skills.italian') }}</option>
                    <option value="Russian">{{ $t('skills.russian') }}</option>
                  </optgroup>
                  <optgroup :label="$t('skills.asianLanguages')">
                    <option value="Chinese">{{ $t('skills.chinese') }}</option>
                    <option value="Japanese">{{ $t('skills.japanese') }}</option>
                    <option value="Korean">{{ $t('skills.korean') }}</option>
                    <option value="Arabic">{{ $t('skills.arabic') }}</option>
                    <option value="Hindi">{{ $t('skills.hindi') }}</option>
                  </optgroup>
                </select>
                <select v-model="lang.proficiency" style="width: 120px" :title="$t('skills.selectLevel')">
                  <option value="">{{ $t('skills.selectLevel') }}</option>
                  <option value="basic">{{ $t('skills.basic') }}</option>
                  <option value="intermediate">{{ $t('skills.intermediate') }}</option>
                  <option value="advanced">{{ $t('skills.advanced') }}</option>
                  <option value="fluent">{{ $t('skills.fluent') }}</option>
                  <option value="native">{{ $t('skills.native') }}</option>
                </select>
                <button class="remove-small-btn" @click="removeLanguage(idx)" :title="$t('common.remove')">×</button>
              </div>
              <button class="add-btn" @click="addLanguage">+ {{ $t('common.add') }} {{ $t('skills.languageTitle') }}</button>
            </div>
            <div class="other-skills">
              <strong>{{ $t('skills.otherTitle') }}:</strong>
              <textarea v-model="form.otherSkills" :placeholder="$t('skills.otherPlaceholder')" rows="3" :title="$t('skills.otherTitle')"></textarea>
            </div>
          </div>
        </div>

        <!-- Right Column -->
        <div class="right-column">
          <!-- Employment Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                </svg>
              </div>
              <h3>{{ $t('employee.employmentInfo') }}</h3>
            </div>
            <div class="info-list">
              <div class="info-item">
                <span class="info-label">{{ $t('employee.department') }}</span>
                <div class="info-value">
                  <select v-model="form.departmentId" :title="$t('employee.department')">
                    <option :value="null">{{ $t('common.select') }}</option>
                    <option v-for="dept in departments" :key="dept.departmentId" :value="dept.departmentId">{{ dept.name }}</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.position') }}</span>
                <div class="info-value">
                  <select v-model="form.positionId" :title="$t('employee.position')">
                    <option :value="null">{{ $t('common.select') }}</option>
                    <option v-for="pos in positions" :key="pos.positionId" :value="pos.positionId">{{ pos.title }}</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.employmentType') }}</span>
                <div class="info-value">
                  <select v-model="form.employmentType" :title="$t('employee.employmentType')">
                    <option value="full-time">{{ $t('employee.fullTime') }}</option>
                    <option value="part-time">{{ $t('employee.partTime') }}</option>
                    <option value="contract">{{ $t('employee.contract') }}</option>
                    <option value="intern">{{ $t('employee.intern') }}</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.hireDate') }}</span>
                <div class="info-value">
                  <input
                    type="text"
                    v-model="form.hireDateEC"
                    placeholder="DD/MM/YYYY"
                    class="ec-date-input"
                    :title="$t('employee.hireDate')"
                  />
                  <small class="ec-hint">Ethiopian Calendar (DD/MM/YYYY)</small>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.manager') }}</span>
                <div class="info-value">
                  <select v-model="form.managerId" :title="$t('employee.manager')">
                    <option :value="null">{{ $t('common.select') }}</option>
                    <option v-for="mgr in managers" :key="mgr.id" :value="mgr.id">{{ mgr.fullName }} ({{ mgr.employeeId }})</option>
                  </select>
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.workLocation') }}</span>
                <div class="info-value">
                  <input type="text" v-model="form.workLocation" :placeholder="$t('employee.workLocationPlaceholder')" :title="$t('employee.workLocation')" />
                </div>
              </div>
              <div class="info-item">
                <span class="info-label">{{ $t('employee.shiftType') }}</span>
                <div class="info-value">
                  <select v-model="form.shiftType" :title="$t('employee.shiftType')">
                    <option value="day">{{ $t('employee.dayShift') }}</option>
                    <option value="night">{{ $t('employee.nightShift') }}</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <!-- Compensation & Allowances Card -->
          <div class="info-card allowances-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 6v6l4 2" />
                </svg>
              </div>
              <h3>{{ $t('employee.compensationAllowances') }}</h3>
            </div>
            <div class="allowances-content">
              <div class="allowance-item basic">
                <div class="allowance-label">{{ $t('employee.basicSalary') }}</div>
                <div class="allowance-value">
                  <input type="number" v-model="form.basicSalary" step="100" :placeholder="$t('employee.basicSalary')" :title="$t('employee.basicSalary')" />
                </div>
              </div>
              <div class="allowance-divider"></div>
              <div class="allowance-item">
                <div class="allowance-label">{{ $t('employee.housingAllowance') }}</div>
                <div class="allowance-value">
                  <input type="number" v-model="form.housingAllowance" step="100" :placeholder="$t('employee.housingAllowance')" :title="$t('employee.housingAllowance')" />
                </div>
              </div>
              <div class="allowance-item">
                <div class="allowance-label">{{ $t('employee.positionAllowance') }}</div>
                <div class="allowance-value">
                  <input type="number" v-model="form.positionAllowance" step="100" :placeholder="$t('employee.positionAllowance')" :title="$t('employee.positionAllowance')" />
                </div>
              </div>
              <div class="allowance-item">
                <div class="allowance-label">{{ $t('employee.transportAllowance') }}</div>
                <div class="allowance-value">
                  <input type="number" v-model="form.transportAllowance" step="100" :placeholder="$t('employee.transportAllowance')" :title="$t('employee.transportAllowance')" />
                </div>
              </div>
              <div class="allowance-item">
                <div class="allowance-label">{{ $t('employee.mobileAllowance') }}</div>
                <div class="allowance-value">
                  <input type="number" v-model="form.mobileAllowance" step="100" :placeholder="$t('employee.mobileAllowance')" :title="$t('employee.mobileAllowance')" />
                </div>
              </div>
              <div class="allowance-divider"></div>
              <div class="allowance-item total">
                <div class="allowance-label">{{ $t('employee.totalAllowances') }}</div>
                <div class="allowance-value">{{ formatCurrency(totalAllowances) }}</div>
              </div>
              <div class="allowance-item gross">
                <div class="allowance-label">{{ $t('employee.grossPay') }}</div>
                <div class="allowance-value gross-amount">{{ formatCurrency(grossPay) }}</div>
              </div>
            </div>
          </div>

          <!-- Spouse Information Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </div>
              <h3>{{ $t('family.spouseTitle') }}</h3>
            </div>
            <div class="spouse-layout">
              <div class="spouse-avatar" @click="triggerSpouseProfileInput" :title="$t('family.profilePicture')">
                <img v-if="spouseProfilePreview || getDocumentWithIndex('spouse_profile', 0)" :src="spouseProfilePreview || getDocumentWithIndex('spouse_profile', 0)" :alt="form.spouseInfo.fullName" @error="(e) => { e.target.src = getAvatarUrl(form.spouseInfo.fullName || 'Spouse') }" />
                <div v-else class="spouse-avatar-placeholder">{{ form.spouseInfo.fullName?.charAt(0) || "S" }}</div>
                <div class="avatar-upload-icon">📷</div>
              </div>
              <input type="file" ref="spouseProfileInput" @change="handleSpouseProfileUpload" style="display: none" accept="image/*" />
              <div class="spouse-info">
                <div class="spouse-name">
                  <input type="text" v-model="form.spouseInfo.fullName" :placeholder="$t('family.spouseNamePlaceholder')" :title="$t('family.spouseFullName')" />
                </div>
                <div class="spouse-detail">
                  <span>{{ $t('family.tinNumber') }}:</span>
                  <input type="text" v-model="form.spouseInfo.tinNumber" :placeholder="$t('family.tinPlaceholder')" :title="$t('family.tinNumber')" />
                </div>
                <div class="spouse-detail">
                  <span>{{ $t('family.dateOfBirth') }}:</span>
                  <input type="text" v-model="form.spouseInfo.dateOfBirthEC" placeholder="DD/MM/YYYY" class="ec-date-input" :title="$t('family.dateOfBirth')" />
                </div>
                <div class="spouse-detail">
                  <span>{{ $t('family.jobStatus') }}:</span>
                  <select v-model="form.spouseInfo.jobStatus" :title="$t('family.jobStatus')">
                    <option value="">{{ $t('common.select') }}</option>
                    <option value="government">{{ $t('family.government') }}</option>
                    <option value="private">{{ $t('family.private') }}</option>
                    <option value="self-employed">{{ $t('family.business') }}</option>
                    <option value="unemployed">{{ $t('family.unemployed') }}</option>
                  </select>
                </div>
                <div class="spouse-detail">
                  <span>{{ $t('family.companyName') }}:</span>
                  <input type="text" v-model="form.spouseInfo.companyName" :placeholder="$t('family.companyName')" :title="$t('family.companyName')" />
                </div>
                <div class="spouse-detail">
                  <span>{{ $t('family.companyAddress') }}:</span>
                  <input type="text" v-model="form.spouseInfo.companyAddress" :placeholder="$t('family.companyAddress')" :title="$t('family.companyAddress')" />
                </div>
                <div class="spouse-document">
                  <button class="upload-small-btn" @click="triggerMarriageCertUpload" :title="$t('common.upload')">📄 {{ $t('family.marriageCertificate') }}</button>
                  <a v-if="getDocumentWithIndex('marriage_certificate', 0)" :href="getDocumentWithIndex('marriage_certificate', 0)" target="_blank" class="file-link-inline">{{ $t('common.view') }}</a>
                  <input type="file" ref="marriageCertInput" @change="handleMarriageCertUpload" style="display: none" />
                </div>
              </div>
            </div>
          </div>

          <!-- Children Information Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
                </svg>
              </div>
              <h3>{{ $t('family.childrenTitle') }} ({{ form.children.length }})</h3>
            </div>
            <div class="children-list-edit">
              <div v-for="(child, idx) in form.children" :key="idx" class="child-edit-item">
                <div class="edit-header">
                  <strong>{{ $t('family.child') }} {{ idx + 1 }}: {{ child.name || $t('family.child') }}</strong>
                  <button class="remove-btn" @click="removeChild(idx)">{{ $t('common.remove') }}</button>
                </div>
                <div class="child-edit-content">
                  <div class="child-avatar-edit" @click="triggerChildProfileUpload(idx)" :title="$t('common.upload')">
                    <img v-if="childProfilePreviews[idx] || getDocumentWithIndex('child_profile', idx)" :src="childProfilePreviews[idx] || getDocumentWithIndex('child_profile', idx)" :alt="child.name || $t('family.child')" @error="(e) => { e.target.src = getAvatarUrl(child.name || $t('family.child')) }" />
                    <div v-else class="child-avatar-placeholder-edit">{{ child.name?.charAt(0) || '👶' }}</div>
                    <div class="avatar-upload-overlay"><span>📷</span></div>
                  </div>
                  <div class="child-info-edit">
                    <div class="child-name-row">
                      <input type="text" v-model="child.name" :placeholder="$t('family.childNamePlaceholder')" class="child-name-input" :title="$t('family.childFullName')" />
                      <input type="text" v-model="child.dateOfBirthEC" placeholder="DD/MM/YYYY" class="child-dob-input ec-date-input" :title="$t('family.dateOfBirth')" />
                    </div>
                    <div class="checkbox-group">
                      <label><input type="checkbox" v-model="child.hasMedicalCondition" /> {{ $t('family.hasMedicalCondition') }}</label>
                      <label><input type="checkbox" v-model="child.isAdopted" /> {{ $t('family.isAdopted') }}</label>
                    </div>
                    <textarea v-if="child.hasMedicalCondition" v-model="child.medicalConditionNotes" :placeholder="$t('family.medicalNotesPlaceholder')" rows="2" class="child-notes" :title="$t('family.medicalConditionNotes')"></textarea>
                    <div class="child-documents-section">
                      <div class="documents-status">
                        <div class="doc-status-item">
                          <span class="status-label">{{ $t('family.birthCertificate') }}:</span>
                          <span v-if="getDocumentWithIndex('child_birth_certificate', idx)" class="status-uploaded">✅ {{ $t('common.uploaded') }}</span>
                          <span v-else class="status-missing">❌ {{ $t('common.missing') }}</span>
                        </div>
                        <div v-if="child.hasMedicalCondition" class="doc-status-item">
                          <span class="status-label">{{ $t('family.medicalReport') }}:</span>
                          <span v-if="getDocumentWithIndex('child_medical_report', idx)" class="status-uploaded">✅ {{ $t('common.uploaded') }}</span>
                          <span v-else class="status-missing">❌ {{ $t('common.missing') }}</span>
                        </div>
                        <div v-if="child.isAdopted" class="doc-status-item">
                          <span class="status-label">{{ $t('family.adoptionCertificate') }}:</span>
                          <span v-if="getDocumentWithIndex('child_adoption_certificate', idx)" class="status-uploaded">✅ {{ $t('common.uploaded') }}</span>
                          <span v-else class="status-missing">❌ {{ $t('common.missing') }}</span>
                        </div>
                      </div>
                      <div class="child-documents-buttons">
                        <button class="upload-small-btn" @click="triggerChildDocUpload(idx, 'birth')" :title="$t('common.upload')">
                          📄 {{ getDocumentWithIndex('child_birth_certificate', idx) ? $t('common.edit') : $t('common.upload') }} {{ $t('family.birthCertificate') }}
                        </button>
                        <button v-if="child.hasMedicalCondition" class="upload-small-btn" @click="triggerChildDocUpload(idx, 'medical')" :title="$t('common.upload')">
                          📋 {{ getDocumentWithIndex('child_medical_report', idx) ? $t('common.edit') : $t('common.upload') }} {{ $t('family.medicalReport') }}
                        </button>
                        <button v-if="child.isAdopted" class="upload-small-btn" @click="triggerChildDocUpload(idx, 'adoption')" :title="$t('common.upload')">
                          📜 {{ getDocumentWithIndex('child_adoption_certificate', idx) ? $t('common.edit') : $t('common.upload') }} {{ $t('family.adoptionCertificate') }}
                        </button>
                      </div>
                      <div class="view-documents" v-if="getDocumentWithIndex('child_birth_certificate', idx) || getDocumentWithIndex('child_medical_report', idx) || getDocumentWithIndex('child_adoption_certificate', idx) || getDocumentWithIndex('child_profile', idx)">
                        <span class="view-label">{{ $t('common.view') }}:</span>
                        <a v-if="getDocumentWithIndex('child_birth_certificate', idx)" :href="getDocumentWithIndex('child_birth_certificate', idx)" target="_blank" class="file-link">{{ $t('common.viewBirthCertificate') }}</a>
                        <a v-if="getDocumentWithIndex('child_medical_report', idx)" :href="getDocumentWithIndex('child_medical_report', idx)" target="_blank" class="file-link">{{ $t('common.viewMedicalReport') }}</a>
                        <a v-if="getDocumentWithIndex('child_adoption_certificate', idx)" :href="getDocumentWithIndex('child_adoption_certificate', idx)" target="_blank" class="file-link">{{ $t('common.viewAdoptionCertificate') }}</a>
                        <a v-if="getDocumentWithIndex('child_profile', idx)" :href="getDocumentWithIndex('child_profile', idx)" target="_blank" class="file-link">{{ $t('family.profilePicture') }}</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <button class="add-btn" @click="addChild">+ {{ $t('common.add') }} {{ $t('family.child') }}</button>
            </div>
          </div>

          <!-- Parents Information Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </div>
              <h3>{{ $t('family.parentsTitle') }}</h3>
            </div>
            <div class="parents-edit-grid">
              <div class="parent-edit-section">
                <h4>{{ $t('family.fatherInfo') }}</h4>
                <input type="text" v-model="form.parentsInfo.father.fullName" :placeholder="$t('family.fatherNamePlaceholder')" :title="$t('family.fatherName')" />
                <input type="text" v-model="form.parentsInfo.father.job" :placeholder="$t('family.jobPlaceholder')" :title="$t('family.jobOccupation')" />
                <input type="number" v-model="form.parentsInfo.father.monthlyIncome" :placeholder="$t('family.monthlyIncome')" :title="$t('family.monthlyIncome')" />
              </div>
              <div class="parent-edit-section">
                <h4>{{ $t('family.motherInfo') }}</h4>
                <input type="text" v-model="form.parentsInfo.mother.fullName" :placeholder="$t('family.motherNamePlaceholder')" :title="$t('family.motherName')" />
                <input type="text" v-model="form.parentsInfo.mother.job" :placeholder="$t('family.jobPlaceholder')" :title="$t('family.jobOccupation')" />
                <input type="number" v-model="form.parentsInfo.mother.monthlyIncome" :placeholder="$t('family.monthlyIncome')" :title="$t('family.monthlyIncome')" />
              </div>
            </div>
            <div class="support-section">
              <div class="support-title">{{ $t('family.supportTitle') }}</div>
              <input type="text" v-model="form.parentsInfo.financialSupport" :placeholder="$t('family.financialPlaceholder')" style="width: 100%; margin-bottom: 8px" :title="$t('family.financialSupport')" />
              <input type="text" v-model="form.parentsInfo.otherSupport" :placeholder="$t('family.otherPlaceholder')" style="width: 100%" :title="$t('family.otherSupport')" />
            </div>
          </div>

          <!-- Work Experience Card -->
          <div class="info-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                </svg>
              </div>
              <h3>{{ $t('employee.workExperience') }} ({{ form.workExperience.length }})</h3>
            </div>
            <div class="work-list-edit">
              <div v-for="(work, idx) in form.workExperience" :key="idx" class="work-edit-item">
                <div class="edit-header">
                  <strong>{{ $t('employee.experience') }} {{ idx + 1 }}</strong>
                  <button class="remove-btn" @click="removeWork(idx)">{{ $t('common.remove') }}</button>
                </div>
                <div class="edit-fields">
                  <input type="text" v-model="work.position" :placeholder="$t('employee.positionPlaceholder')" :title="$t('employee.positionTitle')" />
                  <input type="text" v-model="work.companyName" :placeholder="$t('employee.companyNamePlaceholder')" :title="$t('employee.companyName')" />
                  <input type="text" v-model="work.companyAddress" :placeholder="$t('employee.companyAddressPlaceholder')" :title="$t('company.address')" />
                  <div class="date-group">
                    <input type="text" v-model="work.startDateEC" placeholder="DD/MM/YYYY" class="ec-date-input" :title="$t('employee.startDate')" />
                    <input type="text" v-model="work.endDateEC" placeholder="DD/MM/YYYY" class="ec-date-input" :title="$t('employee.endDate')" />
                  </div>
                  <div class="salary-group">
                    <input type="number" v-model="work.monthlySalary" :placeholder="$t('employee.monthlySalary')" :title="$t('employee.monthlySalary')" />
                    <input type="number" v-model="work.salaryWhenLeft" :placeholder="$t('employee.salaryWhenLeft')" :title="$t('employee.salaryWhenLeft')" />
                  </div>
                  <textarea v-model="work.terminationReason" :placeholder="$t('employee.terminationPlaceholder')" rows="2" :title="$t('employee.reasonForLeaving')"></textarea>
                  <div class="provident-group">
                    <label>
                      <input type="checkbox" v-model="work.providentFundSubmitted" true-value="yes" false-value="no" />
                      {{ $t('employee.providentFundSubmitted') }}
                    </label>
                    <input v-if="work.providentFundSubmitted === 'yes'" type="text" v-model="work.providentFundStartDateEC" placeholder="DD/MM/YYYY" class="ec-date-input" :title="$t('employee.providentFundStartDate')" />
                  </div>
                </div>
                <div class="edit-actions">
                  <button class="upload-small-btn" @click="triggerWorkUpload(idx)" :title="$t('common.upload')">📄 {{ $t('employee.experienceLetter') }}</button>
                </div>
              </div>
              <button class="add-btn" @click="addWork">+ {{ $t('common.add') }} {{ $t('employee.experience') }}</button>
            </div>
          </div>

       <!-- Guarantee Information Card -->
<div class="info-card">
  <div class="card-header">
    <div class="card-header-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5z" />
        <path d="M2 17l10 5 10-5" />
        <path d="M2 12l10 5 10-5" />
      </svg>
    </div>
    <h3>{{ $t('guarantee.title') }} ({{ form.guaranteeInfo.length }})</h3>
  </div>
  <div class="guarantee-list-edit">
    <div v-for="(guarantor, idx) in form.guaranteeInfo" :key="idx" class="guarantor-edit-item">
      <div class="edit-header">
        <strong>{{ $t('guarantee.guarantor') }} {{ idx + 1 }}</strong>
        <button class="remove-btn" @click="removeGuarantor(idx)">{{ $t('common.remove') }}</button>
      </div>
      <div class="edit-fields">
        <div class="form-row-two">
          <input type="text" v-model="guarantor.guarantorName" :placeholder="$t('guarantee.guarantorNamePlaceholder')" :title="$t('guarantee.guarantorName')" />
          <input type="text" v-model="guarantor.guarantorJob" :placeholder="$t('guarantee.jobPlaceholder')" :title="$t('guarantee.guarantorJob')" />
        </div>
        <div class="form-row-two">
          <input type="text" v-model="guarantor.guarantorOfficeName" :placeholder="$t('guarantee.officeNamePlaceholder')" :title="$t('guarantee.guarantorOfficeName')" />
          <input type="text" v-model="guarantor.guarantorOfficeAddress" :placeholder="$t('guarantee.addressPlaceholder')" :title="$t('guarantee.guarantorOfficeAddress')" />
        </div>
        <div class="form-row-two">
          <input type="text" v-model="guarantor.guaranteeLetterDateEC" placeholder="Guarantee Letter Date (DD/MM/YYYY)" class="ec-date-input" :title="$t('guarantee.letterDate')" />
          <input type="text" v-model="guarantor.sdtLetterDateEC" placeholder="SDT Letter Date (DD/MM/YYYY)" class="ec-date-input" :title="$t('guarantee.sdtLetterDate')" />
        </div>
        
        <!-- ========== ADD CONFIRMATION DATE FIELD HERE ========== -->
        <div class="form-row-two">
          <div class="form-field">
            <label>{{ $t('guarantee.confirmationDate') || 'Confirmation Date' }}</label>
            <input 
              type="text" 
              v-model="guarantor.confirmedDateEC" 
              placeholder="DD/MM/YYYY" 
              class="ec-date-input" 
              :title="$t('guarantee.confirmationDate') || 'Confirmation Date'"
            />
            <small class="ec-hint">Ethiopian Calendar (DD/MM/YYYY)</small>
          </div>
          <div class="form-field">
            <!-- Empty or you can add another field here -->
          </div>
        </div>
        <!-- ========== END CONFIRMATION DATE ========== -->
        
      </div>
      <div class="edit-actions">
        <button class="upload-small-btn" @click="triggerGuaranteeUpload(idx, 'guarantee')" :title="$t('common.upload')">📄 {{ $t('guarantee.guaranteeLetter') }}</button>
        <button class="upload-small-btn" @click="triggerGuaranteeUpload(idx, 'sdt')" :title="$t('common.upload')">📄 {{ $t('guarantee.sdtLetter') }}</button>
      </div>
    </div>
    <button class="add-btn" @click="addGuarantor">+ {{ $t('common.add') }} {{ $t('guarantee.guarantor') }}</button>
  </div>
</div>

          <!-- ========== NEW: SCANNED DOCUMENTS SECTION ========== -->
          <div class="info-card scanned-documents-card">
            <div class="card-header">
              <div class="card-header-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M4 4h16v16H4V4z" />
                  <path d="M8 4v16" />
                  <path d="M16 4v16" />
                  <path d="M4 8h16" />
                  <path d="M4 16h16" />
                  <path d="M12 4v16" />
                </svg>
              </div>
              <h3>{{ $t('documents.scannedDocs') || 'Scanned Documents' }}</h3>
              <span class="doc-count-badge">{{ scannedDocumentCount }} {{ $t('documents.files') || 'files' }}</span>
            </div>
            
            <div class="scanned-documents-content">
              <p class="section-description">
                {{ $t('documents.scannedDocsHint') || 'Upload additional documents such as guarantee letters, employment letters, certificates, and other official documents.' }}
              </p>
              
              <div class="documents-grid">
                <!-- 1. Guarantee Letter -->
                <div class="document-upload-item" :class="{ 'has-file': scannedDocs.guaranteeLetter }">
                  <div class="doc-icon">📑</div>
                  <div class="doc-info">
                    <span class="doc-label">{{ $t('guarantee.guaranteeLetter') || 'Guarantee Letter' }}</span>
                    <span class="doc-status">{{ scannedDocs.guaranteeLetter ? $t('common.uploaded') : $t('common.missing') }}</span>
                  </div>
                  <div class="doc-actions">
                    <button 
                      type="button" 
                      class="upload-btn" 
                      @click="triggerScannedDocUpload('guaranteeLetter')"
                      :title="scannedDocs.guaranteeLetter ? $t('common.edit') : $t('common.upload')"
                    >
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                        <polyline points="17 8 12 3 7 8" />
                        <line x1="12" y1="3" x2="12" y2="15" />
                      </svg>
                    </button>
                    <a 
                      v-if="getDocumentUrl('guarantee_letter') || scannedDocs.guaranteeLetterUrl" 
                      :href="getDocumentUrl('guarantee_letter') || scannedDocs.guaranteeLetterUrl" 
                      target="_blank" 
                      class="view-link"
                    >
                      👁️
                    </a>
                    <span v-if="scannedDocs.guaranteeLetter" class="file-name">{{ scannedDocs.guaranteeLetter.name }}</span>
                  </div>
                  <input 
                    type="file" 
                    ref="guaranteeLetterInput" 
                    @change="handleScannedDocUpload($event, 'guaranteeLetter')" 
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                    style="display: none"
                  />
                </div>

                <!-- 2. Employment Letter -->
                <div class="document-upload-item" :class="{ 'has-file': scannedDocs.employmentLetter }">
                  <div class="doc-icon">✉️</div>
                  <div class="doc-info">
                    <span class="doc-label">{{ $t('documents.employmentLetter') || 'Employment Letter' }}</span>
                    <span class="doc-status">{{ scannedDocs.employmentLetter ? $t('common.uploaded') : $t('common.missing') }}</span>
                  </div>
                  <div class="doc-actions">
                    <button 
                      type="button" 
                      class="upload-btn" 
                      @click="triggerScannedDocUpload('employmentLetter')"
                      :title="scannedDocs.employmentLetter ? $t('common.edit') : $t('common.upload')"
                    >
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                        <polyline points="17 8 12 3 7 8" />
                        <line x1="12" y1="3" x2="12" y2="15" />
                      </svg>
                    </button>
                    <a 
                      v-if="getDocumentUrl('employment_letter') || scannedDocs.employmentLetterUrl" 
                      :href="getDocumentUrl('employment_letter') || scannedDocs.employmentLetterUrl" 
                      target="_blank" 
                      class="view-link"
                    >
                      👁️
                    </a>
                    <span v-if="scannedDocs.employmentLetter" class="file-name">{{ scannedDocs.employmentLetter.name }}</span>
                  </div>
                  <input 
                    type="file" 
                    ref="employmentLetterInput" 
                    @change="handleScannedDocUpload($event, 'employmentLetter')" 
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                    style="display: none"
                  />
                </div>

                <!-- 3. Other Document (with custom name) -->
                <div class="document-upload-item" :class="{ 'has-file': scannedDocs.other }">
                  <div class="doc-icon">📎</div>
                  <div class="doc-info">
                    <div class="doc-label-group">
                      <input 
                        type="text" 
                        v-model="scannedDocs.otherName" 
                        :placeholder="$t('documents.otherDocumentName') || 'Other document name...'" 
                        class="doc-name-input"
                      />
                    </div>
                    <span class="doc-status">{{ scannedDocs.other ? $t('common.uploaded') : $t('common.missing') }}</span>
                  </div>
                  <div class="doc-actions">
                    <button 
                      type="button" 
                      class="upload-btn" 
                      @click="triggerScannedDocUpload('other')"
                      :title="scannedDocs.other ? $t('common.edit') : $t('common.upload')"
                    >
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                        <polyline points="17 8 12 3 7 8" />
                        <line x1="12" y1="3" x2="12" y2="15" />
                      </svg>
                    </button>
                    <button 
                      v-if="scannedDocs.other || scannedDocs.otherName" 
                      type="button" 
                      class="remove-btn" 
                      @click="clearScannedDoc('other')"
                      :title="$t('common.remove')"
                    >
                      ✕
                    </button>
                    <a 
                      v-if="getDocumentUrl('other_document') || scannedDocs.otherUrl" 
                      :href="getDocumentUrl('other_document') || scannedDocs.otherUrl" 
                      target="_blank" 
                      class="view-link"
                    >
                      👁️
                    </a>
                    <span v-if="scannedDocs.other" class="file-name">{{ scannedDocs.other.name }}</span>
                  </div>
                  <input 
                    type="file" 
                    ref="otherInput" 
                    @change="handleScannedDocUpload($event, 'other')" 
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                    style="display: none"
                  />
                </div>
              </div>

              <!-- Add Custom Document Button -->
              <button type="button" class="add-doc-btn" @click="addScannedCustomDocument">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
                {{ $t('common.add') }} {{ $t('documents.customDocument') || 'Custom Document' }}
              </button>

              <!-- Custom Documents List -->
              <div 
                v-for="(doc, index) in scannedDocs.custom" 
                :key="`custom-${index}`" 
                class="document-upload-item custom-doc" 
                :class="{ 'has-file': doc.file }"
              >
                <div class="doc-icon">📎</div>
                <div class="doc-info">
                  <input 
                    type="text" 
                    v-model="doc.name" 
                    :placeholder="$t('documents.documentName') || 'Document name...'" 
                    class="doc-name-input"
                  />
                  <span class="doc-status">{{ doc.file ? $t('common.uploaded') : $t('common.missing') }}</span>
                </div>
                <div class="doc-actions">
                  <button 
                    type="button" 
                    class="upload-btn" 
                    @click="triggerScannedCustomUpload(index)"
                    :title="doc.file ? $t('common.edit') : $t('common.upload')"
                  >
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                      <polyline points="17 8 12 3 7 8" />
                      <line x1="12" y1="3" x2="12" y2="15" />
                    </svg>
                  </button>
                  <button 
                    type="button" 
                    class="remove-btn" 
                    @click="removeScannedCustomDocument(index)"
                    :title="$t('common.remove')"
                  >
                    ✕
                  </button>
                  <a 
                    v-if="getDocumentUrl('custom_document', index) || doc.url" 
                    :href="getDocumentUrl('custom_document', index) || doc.url" 
                    target="_blank" 
                    class="view-link"
                  >
                    👁️
                  </a>
                  <span v-if="doc.file" class="file-name">{{ doc.file.name }}</span>
                </div>
                <input 
                  :ref="el => setScannedCustomInputRef(el, index)"
                  type="file" 
                  @change="handleScannedCustomUpload($event, index)" 
                  accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                  style="display: none"
                />
              </div>
              
              <!-- File Size Warning -->
              <div class="file-info-note">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="12" x2="12" y2="16" />
                  <line x1="12" y1="8" x2="12.01" y2="8" />
                </svg>
                <span>{{ $t('documents.fileInfo') || 'Accepted formats: PDF, JPG, PNG, DOC, DOCX. Max size: 5MB per file.' }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-else class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10" />
        <line x1="12" y1="8" x2="12" y2="12" />
        <circle cx="12" cy="16" r="0.5" />
      </svg>
      <h3>{{ $t('messages.noData') }}</h3>
      <router-link to="/employees">{{ $t('common.returnToEmployees') }}</router-link>
    </div>

    <!-- Hidden File Inputs -->
    <input type="file" ref="educationInput" @change="handleEducationUpload" style="display: none" accept=".pdf,.jpg,.jpeg,.png" />
    <input type="file" ref="trainingInput" @change="handleTrainingUpload" style="display: none" accept=".pdf,.jpg,.jpeg,.png" />
    <input type="file" ref="workInput" @change="handleWorkUpload" style="display: none" accept=".pdf,.jpg,.jpeg,.png" />
    <input type="file" ref="guaranteeInput" @change="handleGuaranteeDocUpload" style="display: none" accept=".pdf,.jpg,.jpeg,.png" />
    <input type="file" ref="childDocInput" @change="handleChildDocUpload" style="display: none" accept=".pdf,.jpg,.jpeg,.png" />
    <input type="file" ref="childProfileInput" @change="handleChildProfileUpload" style="display: none" accept="image/*" />

    <!-- Toast Notifications -->
    <div class="toast-container">
      <div v-for="toast in toasts" :key="toast.id" :class="`toast toast-${toast.type}`">
        <span>{{ toast.message }}</span>
        <button @click="removeToast(toast.id)">×</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useI18n } from 'vue-i18n';
import EmployeesService from "@/stores/employee";

const { t } = useI18n();
const route = useRoute();
const router = useRouter();
const employeeId = route.params.id;

// State
const employee = ref(null);
const loading = ref(true);
const saving = ref(false);
const toasts = ref([]);
const profilePreview = ref(null);
const spouseProfilePreview = ref(null);
const childProfilePreviews = ref({});
const departments = ref([]);
const positions = ref([]);
const managers = ref([]);
const nationalIdFile = ref(null);
const nationalityDocFile = ref(null);

// File upload state
let currentEducationIndex = null;
let currentTrainingIndex = null;
let currentWorkIndex = null;
let currentGuaranteeData = null;
let currentChildData = null;

// ========== SCANNED DOCUMENTS STATE ==========
const scannedDocs = ref({
  guaranteeLetter: null,
  guaranteeLetterUrl: null,
  employmentLetter: null,
  employmentLetterUrl: null,
  other: null,
  otherName: '',
  otherUrl: null,
  custom: []
})

const scannedInputRefs = ref({})

// Scanned document file input refs
const guaranteeLetterInput = ref(null)
const employmentLetterInput = ref(null)
const otherInput = ref(null)

// Form data
const form = ref({
  firstName: "",
  lastName: "",
  middleName: "",
  email: "",
  personalEmail: "",
  phone: "",
  
  // EC dates (for display and editing)
  hireDateEC: "",
  dateOfBirthEC: "",
  confirmationDateEC: "",
  terminationDateEC: "",
  
  gender: "",
  maritalStatus: "",
  nationality: "",
  nationalId: "",
  departmentId: null,
  positionId: null,
  managerId: null,
  employmentType: "",
  status: "active",
  workLocation: "",
  shiftType: "day",
  basicSalary: null,
  housingAllowance: 0,
  positionAllowance: 0,
  transportAllowance: 0,
  mobileAllowance: 0,
  birthPlace: { region: "", city: "", subcity: "", district: "" },
  currentCompany: {
    companyName: "",
    companyTin: "",
    companyPhone: "",
    companyEmail: "",
    companyAddress: "",
    poBox: "",
    website: "",
  },
  currentAddress: {
    region: "",
    subcity: "",
    kebele: "",
    district: "",
    poBox: "",
    houseNumber: "",
  },
  permanentAddress: {
    region: "",
    subcity: "",
    kebele: "",
    district: "",
    poBox: "",
    houseNumber: "",
  },
  emergencyContact: {
    name: "",
    relationship: "",
    phone: "",
    alternatePhone: "",
  },
  emergencyContactAddress: { city: "", subcity: "", district: "", kebele: "" },
  bankAccount: {
    bankName: "",
    accountNumber: "",
    accountHolderName: "",
    branch: "",
  },
  spouseInfo: {
    fullName: "",
    tinNumber: "",
    dateOfBirthEC: "",
    jobStatus: "",
    companyName: "",
    companyAddress: "",
  },
  children: [],
  parentsInfo: {
    father: { fullName: "", monthlyIncome: null, job: "" },
    mother: { fullName: "", monthlyIncome: null, job: "" },
    financialSupport: "",
    otherSupport: "",
  },
  education: [],
  training: [],
  workExperience: [],
  guaranteeInfo: [],
  languageSkills: [],
  otherSkills: "",
  nationalityAcquisition: { type: "by_birth" },
  healthInfo: { hasPhysicalInjury: false, injuryDescription: "" },
  legalInfo: { hasCriminalRecord: false, criminalRecordDescription: "" },
});

// Computed
const totalAllowances = computed(
  () =>
    (parseFloat(form.value.housingAllowance) || 0) +
    (parseFloat(form.value.positionAllowance) || 0) +
    (parseFloat(form.value.transportAllowance) || 0) +
    (parseFloat(form.value.mobileAllowance) || 0),
);
const grossPay = computed(
  () => (parseFloat(form.value.basicSalary) || 0) + totalAllowances.value,
);
const getDepartmentName = computed(() => {
  const dept = departments.value.find(
    (d) => d.departmentId === form.value.departmentId,
  );
  return dept?.name || employee.value?.departmentName || "—";
});
const getPositionName = computed(() => {
  const pos = positions.value.find(
    (p) => p.positionId === form.value.positionId,
  );
  return pos?.title || employee.value?.position || "—";
});
const getEmploymentTypeLabel = (type) => {
  const labels = {
    "full-time": t('employee.fullTime'),
    "part-time": t('employee.partTime'),
    contract: t('employee.contract'),
    intern: t('employee.intern'),
  };
  return labels[type] || type;
};
const getAvatarUrl = (name) =>
  `https://ui-avatars.com/api/?background=6366f1&color=fff&bold=true&size=120&name=${encodeURIComponent(name || "User")}`;
const formatDate = (date) => (date ? new Date(date).toLocaleDateString() : "—");
const formatCurrency = (val) =>
  val ? `ETB ${Number(val).toLocaleString()}` : "—";

const getDocumentUrl = (type, index) => {
  const docs = employee.value?.documents;
  if (!docs) return null;

  if (index !== undefined && index !== null) {
    const indexedKey = `${type}_${index}`;
    if (docs[indexedKey]) {
      return docs[indexedKey]?.fileUrl || null;
    }
  }

  if (docs[type]) {
    if (Array.isArray(docs[type])) {
      return docs[type][0]?.fileUrl || null;
    }
    return docs[type]?.fileUrl || null;
  }

  return null;
};

const getDocumentWithIndex = (type, index) => {
  const docs = employee.value?.documents;
  if (!docs) return null;

  const indexedKey = `${type}_${index}`;
  if (docs[indexedKey]) {
    return docs[indexedKey]?.fileUrl || null;
  }

  if (docs[type] && !Array.isArray(docs[type])) {
    return index === 0 ? docs[type]?.fileUrl : null;
  }

  if (docs[type] && Array.isArray(docs[type])) {
    const doc = docs[type].find((d) => d.index === index);
    return doc?.fileUrl || null;
  }

  return null;
};

// ========== SCANNED DOCUMENTS COMPUTED ==========
const scannedDocumentCount = computed(() => {
  let count = 0
  if (scannedDocs.value.guaranteeLetter) count++
  if (scannedDocs.value.employmentLetter) count++
  if (scannedDocs.value.other) count++
  scannedDocs.value.custom.forEach(doc => {
    if (doc.file) count++
  })
  return count
})

// Toast
const addToast = (message, type = "success") => {
  const id = Date.now();
  toasts.value.push({ id, message, type });
  setTimeout(() => removeToast(id), 3000);
};
const removeToast = (id) => {
  toasts.value = toasts.value.filter((t) => t.id !== id);
};

// Cancel
const cancelEdit = () => router.push(`/employees/${employeeId}`);

// Load data
const loadEmployeeData = async () => {
  try {
    loading.value = true;
    const result = await EmployeesService.getEmployeeById(employeeId);
    if (result.success && result.data) {
      employee.value = result.data;
      const emp = result.data;
      
      // Helper function to safely get parentsInfo
      const getParentsInfo = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            father: { fullName: "", monthlyIncome: null, job: "" },
            mother: { fullName: "", monthlyIncome: null, job: "" },
            financialSupport: "",
            otherSupport: ""
          };
        }
        return {
          father: {
            fullName: data.father?.fullName || "",
            monthlyIncome: data.father?.monthlyIncome || null,
            job: data.father?.job || ""
          },
          mother: {
            fullName: data.mother?.fullName || "",
            monthlyIncome: data.mother?.monthlyIncome || null,
            job: data.mother?.job || ""
          },
          financialSupport: data.financialSupport || "",
          otherSupport: data.otherSupport || ""
        };
      };
      
      // Helper function for spouseInfo
      const getSpouseInfo = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            fullName: "",
            tinNumber: "",
            dateOfBirthEC: "",
            jobStatus: "",
            companyName: "",
            companyAddress: "",
          };
        }
        return {
          fullName: data.fullName || "",
          tinNumber: data.tinNumber || "",
          dateOfBirthEC: data.dateOfBirthEC || "",
          jobStatus: data.jobStatus || "",
          companyName: data.companyName || "",
          companyAddress: data.companyAddress || "",
        };
      };
      
      // Helper function for bankAccount
      const getBankAccount = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            bankName: "",
            accountNumber: "",
            accountHolderName: "",
            branch: "",
          };
        }
        return {
          bankName: data.bankName || "",
          accountNumber: data.accountNumber || "",
          accountHolderName: data.accountHolderName || "",
          branch: data.branch || "",
        };
      };
      
      // Helper function for emergencyContact
      const getEmergencyContact = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            name: "",
            relationship: "",
            phone: "",
            alternatePhone: "",
          };
        }
        return {
          name: data.name || "",
          relationship: data.relationship || "",
          phone: data.phone || "",
          alternatePhone: data.alternatePhone || "",
        };
      };
      
      // Helper function for emergencyContactAddress
      const getEmergencyContactAddress = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            city: "",
            subcity: "",
            district: "",
            kebele: "",
          };
        }
        return {
          city: data.city || "",
          subcity: data.subcity || "",
          district: data.district || "",
          kebele: data.kebele || "",
        };
      };
      
      // Helper function for currentAddress
      const getCurrentAddress = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            region: "",
            subcity: "",
            kebele: "",
            district: "",
            poBox: "",
            houseNumber: "",
          };
        }
        return {
          region: data.region || "",
          subcity: data.subcity || "",
          kebele: data.kebele || "",
          district: data.district || "",
          poBox: data.poBox || "",
          houseNumber: data.houseNumber || "",
        };
      };
      
      // Helper function for permanentAddress
      const getPermanentAddress = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            region: "",
            subcity: "",
            kebele: "",
            district: "",
            poBox: "",
            houseNumber: "",
          };
        }
        return {
          region: data.region || "",
          subcity: data.subcity || "",
          kebele: data.kebele || "",
          district: data.district || "",
          poBox: data.poBox || "",
          houseNumber: data.houseNumber || "",
        };
      };
      
      // Helper function for birthPlace
      const getBirthPlace = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            region: "",
            city: "",
            subcity: "",
            district: "",
          };
        }
        return {
          region: data.region || "",
          city: data.city || "",
          subcity: data.subcity || "",
          district: data.district || "",
        };
      };
      
      // Helper function for currentCompany
      const getCurrentCompany = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return {
            companyName: "",
            companyTin: "",
            companyPhone: "",
            companyEmail: "",
            companyAddress: "",
            poBox: "",
            website: "",
          };
        }
        return {
          companyName: data.companyName || "",
          companyTin: data.companyTin || "",
          companyPhone: data.companyPhone || "",
          companyEmail: data.companyEmail || "",
          companyAddress: data.companyAddress || "",
          poBox: data.poBox || "",
          website: data.website || "",
        };
      };
      
      // Helper function for nationalityAcquisition
      const getNationalityAcquisition = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return { type: "by_birth" };
        }
        return {
          type: data.type || "by_birth",
        };
      };
      
      // Helper function for healthInfo
      const getHealthInfo = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return { hasPhysicalInjury: false, injuryDescription: "" };
        }
        return {
          hasPhysicalInjury: data.hasPhysicalInjury || false,
          injuryDescription: data.injuryDescription || "",
        };
      };
      
      // Helper function for legalInfo
      const getLegalInfo = (data) => {
        if (!data || typeof data !== 'object' || Object.keys(data).length === 0) {
          return { hasCriminalRecord: false, criminalRecordDescription: "" };
        }
        return {
          hasCriminalRecord: data.hasCriminalRecord || false,
          criminalRecordDescription: data.criminalRecordDescription || "",
        };
      };
      
      // Helper function for children
      const getChildren = (data) => {
        if (!data || !Array.isArray(data) || data.length === 0) {
          return [];
        }
        return data.map(child => ({
          name: child.name || "",
          dateOfBirthEC: child.dateOfBirthEC || "",
          hasMedicalCondition: child.hasMedicalCondition || false,
          isAdopted: child.isAdopted || false,
          medicalConditionNotes: child.medicalConditionNotes || "",
        }));
      };
      
      // Helper function for education
      const getEducation = (data) => {
        if (!data || !Array.isArray(data) || data.length === 0) {
          return [];
        }
        return data.map(edu => ({
          level: edu.level || "",
          institutionName: edu.institutionName || "",
          institutionAddress: edu.institutionAddress || "",
          startDateEC: edu.startDateEC || "",
          endDateEC: edu.endDateEC || "",
          isCurrent: edu.isCurrent || false,
        }));
      };
      
      // Helper function for training
      const getTraining = (data) => {
        if (!data || !Array.isArray(data) || data.length === 0) {
          return [];
        }
        return data.map(train => ({
          trainingName: train.trainingName || "",
          institutionName: train.institutionName || "",
          institutionAddress: train.institutionAddress || "",
          startDateEC: train.startDateEC || "",
          endDateEC: train.endDateEC || "",
        }));
      };
      
      // Helper function for workExperience
      const getWorkExperience = (data) => {
        if (!data || !Array.isArray(data) || data.length === 0) {
          return [];
        }
        return data.map(work => ({
          position: work.position || "",
          companyName: work.companyName || "",
          companyAddress: work.companyAddress || "",
          startDateEC: work.startDateEC || "",
          endDateEC: work.endDateEC || "",
          monthlySalary: work.monthlySalary || "",
          salaryWhenLeft: work.salaryWhenLeft || "",
          terminationReason: work.terminationReason || "",
          providentFundSubmitted: work.providentFundSubmitted || "no",
          providentFundStartDateEC: work.providentFundStartDateEC || "",
        }));
      };
      
      // Helper function for guaranteeInfo
      const getGuaranteeInfo = (data) => {
        if (!data || !Array.isArray(data) || data.length === 0) {
          return [];
        }
        return data.map(guar => ({
          guarantorName: guar.guarantorName || "",
          guarantorJob: guar.guarantorJob || "",
          guarantorOfficeName: guar.guarantorOfficeName || "",
          guarantorOfficeAddress: guar.guarantorOfficeAddress || "",
          guaranteeLetterNo: guar.guaranteeLetterNo || "",
          guaranteeLetterDateEC: guar.guaranteeLetterDateEC || "",
          sdtLetterNo: guar.sdtLetterNo || "",
          sdtLetterDateEC: guar.sdtLetterDateEC || "",
          confirmedDateEC: guar.confirmedDateEC || "",
        }));
      };

      form.value = {
        // Basic Info
        firstName: emp.firstName || "",
        lastName: emp.lastName || "",
        middleName: emp.middleName || "",
        email: emp.email || emp.workEmail || "",
        personalEmail: emp.personalEmail || "",
        phone: emp.phone || emp.phoneNumber || "",
          fullNameEnglish: emp.fullNameEnglish || "", 
        // ========== EC DATES ONLY ==========
        hireDateEC: emp.hireDateEC || "",
        dateOfBirthEC: emp.dateOfBirthEC || "",
        confirmationDateEC: emp.confirmationDateEC || "",
        terminationDateEC: emp.terminationDateEC || "",
        
        // Personal Details
        gender: emp.gender || "",
        maritalStatus: emp.maritalStatus || "",
        nationality: emp.nationality || "",
        nationalId: emp.nationalId || "",
        
        // Employment
        departmentId: emp.departmentId || null,
        positionId: emp.positionId || null,
        managerId: emp.managerId || null,
        employmentType: emp.employmentType || "",
        status: emp.status || "active",
        workLocation: emp.workLocation || "",
        shiftType: emp.shiftType || "day",
        
        // Salary & Allowances
        basicSalary: emp.basicSalary || emp.salary || null,
        housingAllowance: emp.housingAllowance || 0,
        positionAllowance: emp.positionAllowance || 0,
        transportAllowance: emp.transportAllowance || 0,
        mobileAllowance: emp.mobileAllowance || 0,
        
        // Addresses
        birthPlace: getBirthPlace(emp.birthPlace),
        currentCompany: getCurrentCompany(emp.currentCompany),
        currentAddress: getCurrentAddress(emp.currentAddress),
        permanentAddress: getPermanentAddress(emp.permanentAddress),
        emergencyContact: getEmergencyContact(emp.emergencyContact),
        emergencyContactAddress: getEmergencyContactAddress(emp.emergencyContactAddress),
        bankAccount: getBankAccount(emp.bankAccount),
        
        // Family
        spouseInfo: getSpouseInfo(emp.spouseInfo),
        children: getChildren(emp.children),
        parentsInfo: getParentsInfo(emp.parentsInfo),
        
        // Education & Training
        education: getEducation(emp.education),
        training: getTraining(emp.training),
        workExperience: getWorkExperience(emp.workExperience),
        guaranteeInfo: getGuaranteeInfo(emp.guaranteeInfo),
        
        // Skills
        languageSkills: emp.languageSkills || [],
        otherSkills: emp.otherSkills || "",
        
        // Other
        nationalityAcquisition: getNationalityAcquisition(emp.nationalityAcquisition),
        healthInfo: getHealthInfo(emp.healthInfo),
        legalInfo: getLegalInfo(emp.legalInfo),
      };
      
      // Load scanned documents from employee data
      loadScannedDocuments();
    } else {
      addToast(t('messages.loadError'), "error");
    }
  } catch (error) {
    console.error('Error loading employee:', error);
    addToast(t('messages.loadError'), "error");
  } finally {
    loading.value = false;
  }
};

const loadDropdowns = async () => {
  try {
    const deptRes = await EmployeesService.getDepartments();
    if (deptRes.success) departments.value = deptRes.data;
    const posRes = await EmployeesService.getPositions();
    if (posRes.success) positions.value = posRes.data;
    const empRes = await EmployeesService.getEmployees({ limit: 100 });
    if (empRes.success)
      managers.value = empRes.data.filter((e) => e.id != employeeId);
  } catch (error) {
    console.error("Error loading dropdowns:", error);
  }
};

// ========== LOAD SCANNED DOCUMENTS ==========
const loadScannedDocuments = () => {
  if (!employee.value) return
  
  const docs = employee.value.documents || {}
  
  // Check for guarantee letter
  if (docs.guarantee_letter?.fileUrl) {
    scannedDocs.value.guaranteeLetterUrl = docs.guarantee_letter.fileUrl
  }
  
  // Check for employment letter
  if (docs.employment_letter?.fileUrl) {
    scannedDocs.value.employmentLetterUrl = docs.employment_letter.fileUrl
  }
  
  // Check for other document
  if (docs.other_document?.fileUrl) {
    scannedDocs.value.otherUrl = docs.other_document.fileUrl
    scannedDocs.value.otherName = docs.other_document.fileName || 'Other Document'
  }
  
  // Check for custom documents
  if (docs.custom_document) {
    const customDocs = Array.isArray(docs.custom_document) ? docs.custom_document : [docs.custom_document]
    customDocs.forEach((doc, index) => {
      if (doc.fileUrl) {
        scannedDocs.value.custom.push({
          id: Date.now() + index,
          name: doc.fileName || 'Custom Document',
          file: null,
          url: doc.fileUrl
        })
      }
    })
  }
}

// Profile picture
const profileInput = ref(null);
const triggerProfileInput = () => profileInput.value.click();
const handleProfileUpload = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => (profilePreview.value = ev.target.result);
  reader.readAsDataURL(file);
  const res = await EmployeesService.uploadProfilePicture(employeeId, file);
  if (res.success) addToast(t('messages.uploadSuccess'), "success");
  else addToast(t('messages.uploadError'), "error");
};

// National ID
const nationalIdInput = ref(null);
const triggerNationalIdUpload = () => nationalIdInput.value?.click();
const handleNationalIdSelect = (e) => {
  const file = e.target.files[0];
  if (file) {
    nationalIdFile.value = file;
    addToast(t('employee.fileSelected') + `: ${file.name}`, "success");
  }
};

// Naturalization document
const naturalizationInput = ref(null);
const triggerNaturalizationUpload = () => naturalizationInput.value?.click();
const handleNaturalizationSelect = (e) => {
  const file = e.target.files[0];
  if (file) {
    nationalityDocFile.value = file;
    addToast(t('employee.fileSelected') + `: ${file.name}`, "success");
  }
};

// Spouse
const spouseProfileInput = ref(null);
const marriageCertInput = ref(null);
const triggerSpouseProfileInput = () => spouseProfileInput.value.click();
const handleSpouseProfileUpload = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => (spouseProfilePreview.value = ev.target.result);
  reader.readAsDataURL(file);
  const res = await EmployeesService.uploadEmployeeDocument(
    employeeId,
    file,
    "spouse_profile",
    { index: 0 }
  );
  if (res.success) {
    addToast(t('messages.uploadSuccess'), "success");
    await refreshEmployeeData();
  }
};
const triggerMarriageCertUpload = () => marriageCertInput.value.click();
const handleMarriageCertUpload = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const res = await EmployeesService.uploadEmployeeDocument(
    employeeId,
    file,
    "marriage_certificate",
    { index: 0 }
  );
  if (res.success) {
    addToast(t('messages.uploadSuccess'), "success");
    await refreshEmployeeData();
  }
};

// Children
const addChild = () =>
  form.value.children.push({
    name: "",
    dateOfBirthEC: "",
    hasMedicalCondition: false,
    isAdopted: false,
    medicalConditionNotes: "",
  });
const removeChild = (idx) => form.value.children.splice(idx, 1);

const triggerChildProfileUpload = (idx) => {
  const inputId = `child-profile-input-${idx}`
  let input = document.getElementById(inputId)
  
  if (!input) {
    input = document.createElement('input')
    input.type = 'file'
    input.id = inputId
    input.accept = 'image/jpeg,image/png,image/jpg,image/webp'
    input.style.display = 'none'
    input.onchange = (e) => handleChildProfileUpload(e, idx)
    document.body.appendChild(input)
  }
  
  input.click()
}

const handleChildProfileUpload = async (e, idx) => {
  const file = e.target.files[0]
  if (!file) return
  
  if (!file.type.startsWith('image/')) {
    addToast(t('upload.error'), 'error')
    return
  }
  
  if (file.size > 5 * 1024 * 1024) {
    addToast(t('upload.error'), 'error')
    return
  }
  
  const reader = new FileReader()
  reader.onload = (ev) => {
    childProfilePreviews.value[idx] = ev.target.result
  }
  reader.readAsDataURL(file)
  
  const res = await EmployeesService.uploadEmployeeDocument(employeeId, file, 'child_profile', { index: idx })
  if (res.success) {
    addToast(t('messages.uploadSuccess'), 'success')
    await refreshEmployeeData()
    const newUrl = getDocumentWithIndex('child_profile', idx)
    if (newUrl) {
      childProfilePreviews.value[idx] = newUrl
    }
    e.target.value = ''
  } else {
    addToast(t('messages.uploadError'), 'error')
    delete childProfilePreviews.value[idx]
  }
}

const triggerChildDocUpload = (idx, type) => {
  currentChildData = { idx, type }
  const inputId = `child-doc-input-${idx}-${type}`
  let input = document.getElementById(inputId)
  
  if (!input) {
    input = document.createElement('input')
    input.type = 'file'
    input.id = inputId
    input.accept = '.pdf,.jpg,.jpeg,.png'
    input.style.display = 'none'
    input.onchange = handleChildDocUpload
    document.body.appendChild(input)
  }
  
  input.click()
}

const handleChildDocUpload = async (e) => {
  const file = e.target.files[0]
  if (!file || !currentChildData) return
  
  const { idx, type } = currentChildData
  let documentType = ''
  
  switch(type) {
    case 'birth':
      documentType = 'child_birth_certificate'
      break
    case 'medical':
      documentType = 'child_medical_report'
      break
    case 'adoption':
      documentType = 'child_adoption_certificate'
      break
    default:
      return
  }
  
  const res = await EmployeesService.uploadEmployeeDocument(employeeId, file, documentType, { index: idx })
  if (res.success) {
    addToast(t('messages.uploadSuccess'), 'success')
    await refreshEmployeeData()
  } else {
    addToast(t('messages.uploadError'), 'error')
  }
  e.target.value = ''
  currentChildData = null
}

const refreshEmployeeData = async () => {
  try {
    const result = await EmployeesService.getEmployeeById(employeeId)
    if (result.success && result.data) {
      employee.value = result.data
    }
  } catch (error) {
    console.error('Error refreshing employee data:', error)
  }
}

// Education
const educationInput = ref(null);
const addEducation = () =>
  form.value.education.push({
    level: "",
    institutionName: "",
    institutionAddress: "",
    startDateEC: "",
    endDateEC: "",
    isCurrent: false,
  });
const removeEducation = (idx) => form.value.education.splice(idx, 1);
const triggerEducationUpload = (idx) => {
  currentEducationIndex = idx;
  educationInput.value.click();
};
const handleEducationUpload = async (e) => {
  const file = e.target.files[0];
  if (!file || currentEducationIndex === null) return;
  const res = await EmployeesService.uploadEmployeeDocument(
    employeeId,
    file,
    "education_certificate",
    { index: currentEducationIndex },
  );
  if (res.success) addToast(t('messages.uploadSuccess'), "success");
  currentEducationIndex = null;
};

// Training
const trainingInput = ref(null);
const addTraining = () =>
  form.value.training.push({
    trainingName: "",
    institutionName: "",
    institutionAddress: "",
    startDateEC: "",
    endDateEC: "",
  });
const removeTraining = (idx) => form.value.training.splice(idx, 1);
const triggerTrainingUpload = (idx) => {
  currentTrainingIndex = idx;
  trainingInput.value.click();
};
const handleTrainingUpload = async (e) => {
  const file = e.target.files[0];
  if (!file || currentTrainingIndex === null) return;
  const res = await EmployeesService.uploadEmployeeDocument(
    employeeId,
    file,
    "training_certificate",
    { index: currentTrainingIndex },
  );
  if (res.success) addToast(t('messages.uploadSuccess'), "success");
  currentTrainingIndex = null;
};

// Work Experience
const workInput = ref(null);
const addWork = () =>
  form.value.workExperience.push({
    position: "",
    companyName: "",
    companyAddress: "",
    startDateEC: "",
    endDateEC: "",
    monthlySalary: "",
    salaryWhenLeft: "",
    terminationReason: "",
    providentFundSubmitted: "no",
    providentFundStartDateEC: "",
  });
const removeWork = (idx) => form.value.workExperience.splice(idx, 1);
const triggerWorkUpload = (idx) => {
  currentWorkIndex = idx;
  workInput.value.click();
};
const handleWorkUpload = async (e) => {
  const file = e.target.files[0];
  if (!file || currentWorkIndex === null) return;
  const res = await EmployeesService.uploadEmployeeDocument(
    employeeId,
    file,
    "experience_letter",
    { index: currentWorkIndex },
  );
  if (res.success) addToast(t('messages.uploadSuccess'), "success");
  currentWorkIndex = null;
};

// Guarantee
const guaranteeInput = ref(null);
const addGuarantor = () =>
  form.value.guaranteeInfo.push({
    guarantorName: "",
    guarantorJob: "",
    guarantorOfficeName: "",
    guarantorOfficeAddress: "",
    guaranteeLetterNo: "",
    guaranteeLetterDateEC: "",
    sdtLetterNo: "",
    sdtLetterDateEC: "",
    confirmedDateEC: "",
  });
const removeGuarantor = (idx) => form.value.guaranteeInfo.splice(idx, 1);
const triggerGuaranteeUpload = (idx, type) => {
  currentGuaranteeData = { idx, type };
  guaranteeInput.value.click();
};
const handleGuaranteeDocUpload = async (e) => {
  const file = e.target.files[0];
  if (!file || !currentGuaranteeData) return;
  const types = { guarantee: "guarantee_letter", sdt: "sdt_letter" };
  const res = await EmployeesService.uploadEmployeeDocument(
    employeeId,
    file,
    types[currentGuaranteeData.type],
    { index: currentGuaranteeData.idx },
  );
  if (res.success) addToast(t('messages.uploadSuccess'), "success");
  currentGuaranteeData = null;
};

// Language
const addLanguage = () =>
  form.value.languageSkills.push({ language: "", proficiency: "" });
const removeLanguage = (idx) => form.value.languageSkills.splice(idx, 1);

// ========== SCANNED DOCUMENTS METHODS ==========
const triggerScannedDocUpload = (type) => {
  const inputMap = {
    guaranteeLetter: guaranteeLetterInput,
    employmentLetter: employmentLetterInput,
    other: otherInput
  }
  const input = inputMap[type]
  if (input && input.value) {
    input.value.click()
  }
}

const handleScannedDocUpload = async (event, type) => {
  const file = event.target.files?.[0]
  if (!file) return
  
  // Validate file size (5MB max)
  if (file.size > 5 * 1024 * 1024) {
    addToast('File size must be less than 5MB', 'error')
    event.target.value = ''
    return
  }
  
  // Validate file type
  const validTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 
                      'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
  if (!validTypes.includes(file.type) && 
      !file.name.endsWith('.pdf') && 
      !file.name.endsWith('.doc') && 
      !file.name.endsWith('.docx')) {
    addToast('Invalid file type. Please upload PDF, JPG, PNG, DOC, or DOCX.', 'error')
    event.target.value = ''
    return
  }
  
  // Map to the correct ref
  const typeMap = {
    guaranteeLetter: { file: 'guaranteeLetter', url: 'guaranteeLetterUrl' },
    employmentLetter: { file: 'employmentLetter', url: 'employmentLetterUrl' },
    other: { file: 'other', url: 'otherUrl' }
  }
  
  const mapped = typeMap[type]
  if (mapped) {
    scannedDocs.value[mapped.file] = file
    scannedDocs.value[mapped.url] = URL.createObjectURL(file)
  }
  
  addToast(`${file.name} selected`, 'success')
  event.target.value = ''
}

const clearScannedDoc = (type) => {
  const typeMap = {
    other: { file: 'other', name: 'otherName', url: 'otherUrl' }
  }
  const mapped = typeMap[type]
  if (mapped) {
    scannedDocs.value[mapped.file] = null
    scannedDocs.value[mapped.name] = ''
    scannedDocs.value[mapped.url] = null
  }
}

const addScannedCustomDocument = () => {
  scannedDocs.value.custom.push({ 
    id: Date.now(), 
    name: '', 
    file: null,
    url: null
  })
}

const removeScannedCustomDocument = (index) => {
  scannedDocs.value.custom.splice(index, 1)
}

const setScannedCustomInputRef = (el, index) => {
  if (el) {
    scannedInputRefs.value[index] = el
  }
}

const triggerScannedCustomUpload = (index) => {
  const input = scannedInputRefs.value[index]
  if (input) {
    input.click()
  }
}

const handleScannedCustomUpload = (event, index) => {
  const file = event.target.files?.[0]
  if (!file) return
  
  // Validate file size (5MB max)
  if (file.size > 5 * 1024 * 1024) {
    addToast('File size must be less than 5MB', 'error')
    event.target.value = ''
    return
  }
  
  // Validate file type
  const validTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 
                      'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
  if (!validTypes.includes(file.type) && 
      !file.name.endsWith('.pdf') && 
      !file.name.endsWith('.doc') && 
      !file.name.endsWith('.docx')) {
    addToast('Invalid file type. Please upload PDF, JPG, PNG, DOC, or DOCX.', 'error')
    event.target.value = ''
    return
  }
  
  scannedDocs.value.custom[index].file = file
  scannedDocs.value.custom[index].url = URL.createObjectURL(file)
  
  addToast(`${file.name} selected`, 'success')
  event.target.value = ''
}

// Clean data function
const cleanData = (data) => {
  if (data === null || data === undefined) return null;
  if (typeof data === "string") {
    const trimmed = data.trim();
    return trimmed === "" ? null : trimmed;
  }
  if (Array.isArray(data)) {
    return data.map((item) => cleanData(item)).filter((item) => item !== null);
  }
  if (typeof data === "object") {
    const cleaned = {};
    for (const [key, value] of Object.entries(data)) {
      const cleanedValue = cleanData(value);
      if (cleanedValue !== null && cleanedValue !== undefined) {
        if (
          typeof cleanedValue === "object" &&
          Object.keys(cleanedValue).length === 0
        )
          continue;
        cleaned[key] = cleanedValue;
      }
    }
    return Object.keys(cleaned).length > 0 ? cleaned : null;
  }
  return data;
};

// Save
const saveEmployee = async () => {
  saving.value = true;
  try {
    if (nationalIdFile.value) {
      await EmployeesService.uploadEmployeeDocument(
        employeeId,
        nationalIdFile.value,
        "national_id",
      );
    }
    if (nationalityDocFile.value) {
      await EmployeesService.uploadEmployeeDocument(
        employeeId,
        nationalityDocFile.value,
        "naturalization_certificate",
      );
    }

    // ========== UPLOAD SCANNED DOCUMENTS ==========
    // 1. Guarantee Letter
    if (scannedDocs.value.guaranteeLetter) {
      await EmployeesService.uploadEmployeeDocument(
        employeeId,
        scannedDocs.value.guaranteeLetter,
        'guarantee_letter'
      )
    }
    
    // 2. Employment Letter
    if (scannedDocs.value.employmentLetter) {
      await EmployeesService.uploadEmployeeDocument(
        employeeId,
        scannedDocs.value.employmentLetter,
        'employment_letter'
      )
    }
    
    // 3. Other Document
    if (scannedDocs.value.other) {
      await EmployeesService.uploadEmployeeDocument(
        employeeId,
        scannedDocs.value.other,
        'other_document',
        { description: scannedDocs.value.otherName || 'Other Document' }
      )
    }
    
    // 4. Custom Documents
    for (let i = 0; i < scannedDocs.value.custom.length; i++) {
      const doc = scannedDocs.value.custom[i]
      if (doc.file) {
        await EmployeesService.uploadEmployeeDocument(
          employeeId,
          doc.file,
          'custom_document',
          { 
            index: i,
            description: doc.name || 'Custom Document'
          }
        )
      }
    }

    const updateData = {
      firstName: form.value.firstName || undefined,
      lastName: form.value.lastName || undefined,
      middleName: form.value.middleName || undefined,
        fullNameEnglish: form.value.fullNameEnglish || undefined,
      email: form.value.email || undefined,
      personalEmail: form.value.personalEmail || undefined,
      phone: form.value.phone || undefined,
      gender: form.value.gender || undefined,
      maritalStatus: form.value.maritalStatus || undefined,
      nationality: form.value.nationality || undefined,
      nationalId: form.value.nationalId || undefined,
      departmentId: form.value.departmentId,
      positionId: form.value.positionId,
      managerId: form.value.managerId,
      employmentType: form.value.employmentType || undefined,
      status: form.value.status,
      workLocation: form.value.workLocation || undefined,
      shiftType: form.value.shiftType,
      basicSalary: form.value.basicSalary
        ? Number(form.value.basicSalary)
        : undefined,
      housingAllowance: form.value.housingAllowance
        ? Number(form.value.housingAllowance)
        : 0,
      positionAllowance: form.value.positionAllowance
        ? Number(form.value.positionAllowance)
        : 0,
      transportAllowance: form.value.transportAllowance
        ? Number(form.value.transportAllowance)
        : 0,
      mobileAllowance: form.value.mobileAllowance
        ? Number(form.value.mobileAllowance)
        : 0,
      
      // ========== EC DATES ==========
      hireDateEC: form.value.hireDateEC || undefined,
      dateOfBirthEC: form.value.dateOfBirthEC || undefined,
      confirmationDateEC: form.value.confirmationDateEC || undefined,
      terminationDateEC: form.value.terminationDateEC || undefined,
    };

    if (
      form.value.birthPlace &&
      Object.values(form.value.birthPlace).some((v) => v)
    ) {
      updateData.birthPlace = cleanData(form.value.birthPlace);
    }
    if (
      form.value.currentCompany &&
      Object.values(form.value.currentCompany).some((v) => v)
    ) {
      updateData.currentCompany = cleanData(form.value.currentCompany);
    }
    if (
      form.value.currentAddress &&
      Object.values(form.value.currentAddress).some((v) => v)
    ) {
      updateData.currentAddress = cleanData(form.value.currentAddress);
    }
    if (
      form.value.permanentAddress &&
      Object.values(form.value.permanentAddress).some((v) => v)
    ) {
      updateData.permanentAddress = cleanData(form.value.permanentAddress);
    }
    if (
      form.value.emergencyContact &&
      Object.values(form.value.emergencyContact).some((v) => v)
    ) {
      updateData.emergencyContact = cleanData(form.value.emergencyContact);
    }
    if (
      form.value.emergencyContactAddress &&
      Object.values(form.value.emergencyContactAddress).some((v) => v)
    ) {
      updateData.emergencyContactAddress = cleanData(
        form.value.emergencyContactAddress,
      );
    }
    if (
      form.value.bankAccount &&
      Object.values(form.value.bankAccount).some((v) => v)
    ) {
      updateData.bankAccount = cleanData(form.value.bankAccount);
    }
    if (
      form.value.spouseInfo &&
      Object.values(form.value.spouseInfo).some((v) => v)
    ) {
      updateData.spouseInfo = cleanData(form.value.spouseInfo);
    }

    if (form.value.children && form.value.children.length > 0) {
      updateData.children = form.value.children
        .map((child) => cleanData(child))
        .filter((c) => c && c.name);
    }
    if (
      form.value.parentsInfo &&
      (form.value.parentsInfo.father?.fullName ||
        form.value.parentsInfo.mother?.fullName)
    ) {
      updateData.parentsInfo = cleanData(form.value.parentsInfo);
    }
    if (form.value.education && form.value.education.length > 0) {
      updateData.education = form.value.education
        .map((edu) => cleanData(edu))
        .filter((e) => e && e.level);
    }
    if (form.value.training && form.value.training.length > 0) {
      updateData.training = form.value.training
        .map((train) => cleanData(train))
        .filter((t) => t && t.trainingName);
    }
    if (form.value.workExperience && form.value.workExperience.length > 0) {
      updateData.workExperience = form.value.workExperience
        .map((work) => cleanData(work))
        .filter((w) => w && w.position);
    }
    if (form.value.guaranteeInfo && form.value.guaranteeInfo.length > 0) {
      updateData.guaranteeInfo = form.value.guaranteeInfo
        .map((guar) => cleanData(guar))
        .filter((g) => g && g.guarantorName);
    }
    if (form.value.languageSkills && form.value.languageSkills.length > 0) {
      updateData.languageSkills = form.value.languageSkills
        .map((lang) => cleanData(lang))
        .filter((l) => l && l.language);
    }

    if (form.value.otherSkills) {
      updateData.otherSkills = form.value.otherSkills;
    }
    if (form.value.nationalityAcquisition) {
      updateData.nationalityAcquisition = cleanData(
        form.value.nationalityAcquisition,
      );
    }
    if (form.value.healthInfo && form.value.healthInfo.hasPhysicalInjury) {
      updateData.healthInfo = cleanData(form.value.healthInfo);
    }
    if (form.value.legalInfo && form.value.legalInfo.hasCriminalRecord) {
      updateData.legalInfo = cleanData(form.value.legalInfo);
    }

    Object.keys(updateData).forEach((key) => {
      if (updateData[key] === undefined || updateData[key] === null) {
        delete updateData[key];
      }
    });

    const response = await EmployeesService.updateEmployee(
      employeeId,
      updateData,
    );
    if (response.success) {
      addToast(t('messages.saveSuccess'), "success");
      setTimeout(() => router.push(`/employees/${employeeId}`), 1500);
    } else {
      addToast(response.error || t('messages.saveError'), "error");
    }
  } catch (error) {
    console.error("Save error:", error);
    const errorMessage =
      error.response?.data?.message || error.message || t('messages.saveError');
    addToast(errorMessage, "error");
  } finally {
    saving.value = false;
  }
};

// Error handler
const handleImageError = (e) => {
  e.target.src = getAvatarUrl(employee.value?.fullName || "Employee");
};

onMounted(async () => {
  await Promise.all([loadEmployeeData(), loadDropdowns()]);
});
</script>

<style scoped>
/* Add to your existing styles */
.child-documents-section {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid #eef2ff;
}

.documents-status {
  margin-bottom: 12px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.doc-status-item {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 12px;
}

.status-label {
  font-weight: 500;
  color: #64748b;
  min-width: 120px;
}

.status-uploaded {
  color: #10b981;
}

.status-missing {
  color: #ef4444;
}

.view-documents {
  margin-top: 12px;
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  padding: 8px;
  background: #f8fafc;
  border-radius: 8px;
}

.view-label {
  font-size: 12px;
  font-weight: 500;
  color: #64748b;
}

.file-link {
  color: #6366f1;
  text-decoration: none;
  font-size: 12px;
  padding: 2px 8px;
  background: #eef2ff;
  border-radius: 12px;
}

.file-link:hover {
  background: #e0e7ff;
  text-decoration: underline;
}

.child-avatar-edit {
  position: relative;
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  overflow: hidden;
  flex-shrink: 0;
  transition: transform 0.2s ease;
}

.child-avatar-edit:hover {
  transform: scale(1.05);
}

.child-avatar-edit img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.child-avatar-placeholder-edit {
  font-size: 32px;
  font-weight: 600;
  color: #6366f1;
}

.avatar-upload-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.2s ease;
}

.child-avatar-edit:hover .avatar-upload-overlay {
  opacity: 1;
}

.avatar-upload-overlay span {
  font-size: 24px;
  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
}
.children-list-edit {
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.child-edit-item {
  background: #f8fafc;
  border-radius: 12px;
  padding: 16px;
  border: 1px solid #eef2ff;
}

.child-edit-content {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}

.child-avatar-edit {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  overflow: hidden;
  flex-shrink: 0;
}

.child-avatar-edit img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.child-avatar-placeholder-edit {
  font-size: 32px;
}

.child-info-edit {
  flex: 1;
  min-width: 200px;
}

.child-name-row {
  display: flex;
  gap: 12px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.child-name-input {
  flex: 2;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 14px;
}

.child-dob-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 14px;
}

.child-notes {
  width: 100%;
  margin-top: 8px;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  resize: vertical;
}

.child-documents-buttons {
  display: flex;
  gap: 8px;
  margin-top: 12px;
  flex-wrap: wrap;
}

.checkbox-group {
  display: flex;
  gap: 20px;
  margin: 8px 0;
  flex-wrap: wrap;
}

.checkbox-group label {
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  font-size: 13px;
}

@media (max-width: 768px) {
  .child-edit-content {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }

  .child-name-row {
    flex-direction: column;
  }

  .child-name-input,
  .child-dob-input {
    width: 100%;
  }

  .child-documents-buttons {
    justify-content: center;
  }
}
.edit-name-container {
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
}
.name-input {
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 20px;
  font-weight: 600;
  width: 200px;
}
.name-input:focus {
  outline: none;
  border-color: #6366f1;
}
.action-buttons {
  display: flex;
  gap: 12px;
}
.avatar-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.2s;
  cursor: pointer;
}
.employee-avatar-large:hover .avatar-overlay {
  opacity: 1;
}
.avatar-overlay svg {
  width: 32px;
  height: 32px;
  color: white;
}
.upload-small-btn {
  background: #eef2ff;
  border: none;
  padding: 5px 12px;
  border-radius: 6px;
  font-size: 11px;
  cursor: pointer;
  color: #6366f1;
  margin: 4px;
}
.upload-small-btn:hover {
  background: #e0e7ff;
}
.add-btn {
  background: #f1f5f9;
  border: 1px dashed #cbd5e1;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 12px;
  color: #6366f1;
  width: 100%;
  margin-top: 8px;
}
.add-btn:hover {
  background: #eef2ff;
  border-color: #6366f1;
}
.remove-btn {
  background: #ef4444;
  color: white;
  border: none;
  padding: 4px 12px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 12px;
}
.remove-small-btn {
  background: #ef4444;
  color: white;
  border: none;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 16px;
}
.spouse-avatar {
  position: relative;
  cursor: pointer;
}
.spouse-avatar .avatar-upload-icon {
  position: absolute;
  bottom: 0;
  right: 0;
  background: #6366f1;
  color: white;
  border-radius: 50%;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  opacity: 0;
  transition: opacity 0.2s;
}
.spouse-avatar:hover .avatar-upload-icon {
  opacity: 1;
}
.child-avatar-edit {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background: #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  position: relative;
}
.child-avatar-placeholder-edit {
  font-size: 24px;
}
.checkbox-group {
  display: flex;
  gap: 16px;
  margin: 8px 0;
}
.date-group,
.salary-group {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-bottom: 8px;
}
.form-row-two {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-bottom: 8px;
}
.edit-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}
.edit-fields {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.edit-actions {
  margin-top: 12px;
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
.education-edit-item,
.training-edit-item,
.work-edit-item,
.guarantor-edit-item,
.child-edit-item {
  background: #f8fafc;
  border-radius: 12px;
  padding: 14px;
  margin-bottom: 16px;
  border: 1px solid #eef2ff;
}
.parents-edit-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  padding: 20px 24px;
}
.parent-edit-section h4 {
  font-size: 14px;
  color: #6366f1;
  margin-bottom: 12px;
}
.parent-edit-section input {
  width: 100%;
  margin-bottom: 10px;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
}
.guarantee-list-edit,
.education-list-edit,
.training-list-edit,
.work-list-edit,
.children-list-edit {
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.skills-list {
  padding: 12px 20px;
}
.field-hint.success {
  color: #10b981;
}
.file-link-inline {
  color: #6366f1;
  text-decoration: none;
  font-size: 12px;
  margin-left: 10px;
  padding: 2px 8px;
  background: #eef2ff;
  border-radius: 14px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

/* EC Date Input Styles */
.ec-date-input {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 13px;
  font-family: inherit;
  transition: all 0.2s;
  background: white;
}

.ec-date-input:focus {
  outline: none;
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.1);
}

.ec-hint {
  display: block;
  color: #6366f1;
  font-size: 11px;
  margin-top: 4px;
  opacity: 0.7;
}

/* For child date inputs */
.child-dob-input.ec-date-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 14px;
}

/* Main container styles */
.employee-edit {
  max-width: 1200px;
  margin: 0 auto;
  padding: 32px 24px;
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #f0f4f8 100%);
}
.loading-state {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  gap: 16px;
}
.loading-spinner {
  width: 48px;
  height: 48px;
  border: 3px solid #e2e8f0;
  border-top-color: #6366f1;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
.action-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 28px;
}
.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 18px;
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  font-size: 13px;
  font-weight: 500;
  color: #475569;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.2s;
}
.action-btn svg {
  width: 16px;
  height: 16px;
}
.action-btn:hover {
  background: #f8fafc;
  border-color: #cbd5e1;
}
.action-btn.primary {
  background: #6366f1;
  border-color: #6366f1;
  color: white;
}
.action-btn.primary:hover {
  background: #4f46e5;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
}
.hero-section {
  background: white;
  border-radius: 24px;
  padding: 32px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 28px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
}
.hero-left {
  display: flex;
  align-items: center;
  gap: 32px;
}
.employee-avatar-large {
  position: relative;
  width: 120px;
  height: 120px;
  flex-shrink: 0;
  cursor: pointer;
}
.employee-avatar-large img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 4px solid white;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}
.employee-basic h1 {
  font-size: 28px;
  font-weight: 700;
  color: #0f172a;
  margin: 0 0 10px 0;
}
.employee-tags {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.tag {
  padding: 5px 14px;
  background: #f1f5f9;
  border-radius: 20px;
  font-size: 13px;
  font-weight: 500;
  color: #475569;
}
.hero-right {
  text-align: right;
}
.employee-code {
  margin-bottom: 12px;
}
.code-label {
  font-size: 11px;
  color: #94a3b8;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  display: block;
}
.code-value {
  font-size: 20px;
  font-weight: 700;
  color: #0f172a;
}
.status-select {
  display: inline-block;
  padding: 6px 18px;
  border-radius: 30px;
  font-size: 13px;
  font-weight: 600;
  border: none;
  cursor: pointer;
}
.status-select.active {
  background: #10b98115;
  color: #10b981;
}
.stats-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 32px;
}
.stat-card {
  background: white;
  border-radius: 20px;
  padding: 18px 20px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  transition: all 0.2s;
}
.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
}
.stat-card-icon {
  width: 48px;
  height: 48px;
  background: #f1f5f9;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.stat-card-icon svg {
  width: 24px;
  height: 24px;
  color: #6366f1;
}
.stat-card-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.stat-label {
  font-size: 11px;
  color: #94a3b8;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.stat-number {
  font-size: 14px;
  font-weight: 600;
  color: #1e293b;
}
.content-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}
.left-column,
.right-column {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.info-card {
  background: white;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.card-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 18px 24px;
  background: #fafcfc;
  border-bottom: 1px solid #e9edf2;
}
.card-header-icon {
  width: 32px;
  height: 32px;
  background: #f1f5f9;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.card-header-icon svg {
  width: 16px;
  height: 16px;
  color: #6366f1;
}
.card-header h3 {
  font-size: 16px;
  font-weight: 600;
  color: #0f172a;
  margin: 0;
}
.info-list {
  padding: 20px 24px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.info-item {
  display: flex;
  align-items: center;
  gap: 14px;
}
.info-label {
  width: 140px;
  font-size: 13px;
  color: #64748b;
}
.info-value {
  flex: 1;
}
.info-value input,
.info-value select {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 13px;
}
.allowances-card .allowances-content {
  padding: 20px 24px;
}
.allowance-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
}
.allowance-item input {
  width: 150px;
  padding: 6px 10px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  text-align: right;
}
.allowance-divider {
  height: 1px;
  background: #eef2ff;
  margin: 8px 0;
}
.allowance-item.total .allowance-value {
  color: #f59e0b;
  font-size: 16px;
  font-weight: 700;
}
.allowance-item.gross .allowance-value {
  color: #10b981;
  font-size: 18px;
  font-weight: 700;
}
.spouse-layout {
  display: flex;
  gap: 20px;
  padding: 20px;
  align-items: flex-start;
}
.spouse-avatar {
  flex-shrink: 0;
  width: 90px;
  height: 90px;
  position: relative;
}
.spouse-avatar img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #e2e8f0;
}
.spouse-avatar-placeholder {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: linear-gradient(135deg, #6366f1, #4f46e5);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 36px;
  font-weight: 600;
  color: white;
}
.spouse-info {
  flex: 1;
}
.spouse-name {
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 12px;
}
.spouse-detail {
  font-size: 13px;
  color: #475569;
  margin-bottom: 8px;
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: 8px;
}
.spouse-detail span {
  font-weight: 600;
  color: #64748b;
  min-width: 130px;
}
.toast-container {
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 1100;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.toast {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  animation: slideIn 0.2s ease;
}
.toast-success {
  border-left: 3px solid #10b981;
  background: #f0fdf4;
}
.toast-error {
  border-left: 3px solid #ef4444;
  background: #fef2f2;
}
.toast button {
  background: none;
  border: none;
  font-size: 18px;
  cursor: pointer;
  color: #64748b;
  margin-left: auto;
}
@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateX(100%);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}
@media (max-width: 900px) {
  .stats-cards {
    grid-template-columns: repeat(2, 1fr);
  }
  .content-grid {
    grid-template-columns: 1fr;
  }
  .parents-edit-grid {
    grid-template-columns: 1fr;
  }
}
@media (max-width: 768px) {
  .employee-edit {
    padding: 20px 16px;
  }
  .hero-section {
    flex-direction: column;
    text-align: center;
    gap: 24px;
  }
  .hero-left {
    flex-direction: column;
  }
  .hero-right {
    text-align: center;
  }
  .stats-cards {
    grid-template-columns: 1fr;
  }
  .info-item {
    flex-direction: column;
    align-items: flex-start;
  }
  .info-label {
    width: 100%;
  }
  .edit-name-container {
    flex-direction: column;
  }
  .name-input {
    width: 100%;
  }
  .spouse-layout {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  .spouse-detail {
    justify-content: center;
  }
  .date-group,
  .salary-group {
    grid-template-columns: 1fr;
  }
}

.edit-name-container {
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
}
.name-input {
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 20px;
  font-weight: 600;
  width: 200px;
}
.name-input:focus {
  outline: none;
  border-color: #6366f1;
}
.tag-select {
  padding: 5px 14px;
  background: #f1f5f9;
  border-radius: 20px;
  font-size: 13px;
  border: none;
  cursor: pointer;
}
.action-buttons {
  display: flex;
  gap: 12px;
}
.avatar-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.2s;
  cursor: pointer;
}
.employee-avatar-large:hover .avatar-overlay {
  opacity: 1;
}
.avatar-overlay svg {
  width: 32px;
  height: 32px;
  color: white;
}
.upload-small-btn {
  background: #eef2ff;
  border: none;
  padding: 5px 12px;
  border-radius: 6px;
  font-size: 11px;
  cursor: pointer;
  color: #6366f1;
  margin: 4px;
}
.upload-small-btn:hover {
  background: #e0e7ff;
}
.add-btn {
  background: #f1f5f9;
  border: 1px dashed #cbd5e1;
  padding: 8px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 12px;
  color: #6366f1;
  width: 100%;
  margin-top: 8px;
}
.add-btn:hover {
  background: #eef2ff;
  border-color: #6366f1;
}
.remove-child-btn {
  background: #ef4444;
  color: white;
  border: none;
  width: 28px;
  height: 28px;
  border-radius: 20px;
  cursor: pointer;
  font-size: 16px;
  align-self: center;
}
.remove-child-btn:hover {
  background: #dc2626;
}
.remove-small-btn {
  background: #ef4444;
  color: white;
  border: none;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 16px;
}
.education-item,
.training-item,
.work-item,
.guarantor-card-item {
  background: #f8fafc;
  border-radius: 12px;
  padding: 12px;
  margin-bottom: 12px;
  border: 1px solid #eef2ff;
}
input,
select,
textarea {
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  padding: 6px 10px;
  font-size: 13px;
}
input:focus,
select:focus,
textarea:focus {
  outline: none;
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.1);
}
.spouse-avatar {
  cursor: pointer;
}
.child-avatar {
  cursor: pointer;
}
.file-link-inline {
  color: #6366f1;
  text-decoration: none;
  font-size: 12px;
  margin-left: 10px;
  padding: 2px 8px;
  background: #eef2ff;
  border-radius: 14px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.file-link-inline:hover {
  background: #e0e7ff;
  text-decoration: underline;
}
.toast-container {
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 1100;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.toast {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  animation: slideIn 0.2s ease;
}
.toast-success {
  border-left: 3px solid #10b981;
  background: #f0fdf4;
}
.toast-error {
  border-left: 3px solid #ef4444;
  background: #fef2f2;
}
.toast button {
  background: none;
  border: none;
  font-size: 18px;
  cursor: pointer;
  color: #64748b;
  margin-left: auto;
}
@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateX(100%);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

/* Main container styles */
.employee-edit {
  max-width: 1200px;
  margin: 0 auto;
  padding: 32px 24px;
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #f0f4f8 100%);
}

/* Loading state */
.loading-state {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  gap: 16px;
}
.loading-spinner {
  width: 48px;
  height: 48px;
  border: 3px solid #e2e8f0;
  border-top-color: #6366f1;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* Action bar */
.action-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 28px;
}
.action-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 18px;
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  font-size: 13px;
  font-weight: 500;
  color: #475569;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.2s;
}
.action-btn svg {
  width: 16px;
  height: 16px;
}
.action-btn:hover {
  background: #f8fafc;
  border-color: #cbd5e1;
}
.action-btn.primary {
  background: #6366f1;
  border-color: #6366f1;
  color: white;
}
.action-btn.primary:hover {
  background: #4f46e5;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
}

/* Hero section */
.hero-section {
  background: white;
  border-radius: 24px;
  padding: 32px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 28px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
}
.hero-left {
  display: flex;
  align-items: center;
  gap: 32px;
}
.employee-avatar-large {
  position: relative;
  width: 120px;
  height: 120px;
  flex-shrink: 0;
  cursor: pointer;
}
.employee-avatar-large img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 4px solid white;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}
.employee-basic h1 {
  font-size: 28px;
  font-weight: 700;
  color: #0f172a;
  margin: 0 0 10px 0;
}
.employee-tags {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.tag {
  padding: 5px 14px;
  background: #f1f5f9;
  border-radius: 20px;
  font-size: 13px;
  font-weight: 500;
  color: #475569;
}
.hero-right {
  text-align: right;
}
.employee-code {
  margin-bottom: 12px;
}
.code-label {
  font-size: 11px;
  color: #94a3b8;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  display: block;
}
.code-value {
  font-size: 20px;
  font-weight: 700;
  color: #0f172a;
}
.status-select {
  display: inline-block;
  padding: 6px 18px;
  border-radius: 30px;
  font-size: 13px;
  font-weight: 600;
  border: none;
  cursor: pointer;
}
.status-select.active {
  background: #10b98115;
  color: #10b981;
}
.status-select.on-leave {
  background: #f59e0b15;
  color: #f59e0b;
}
.status-select.terminated {
  background: #ef444415;
  color: #ef4444;
}

/* Stats cards */
.stats-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 32px;
}
.stat-card {
  background: white;
  border-radius: 20px;
  padding: 18px 20px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  transition: all 0.2s;
}
.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
}
.stat-card-icon {
  width: 48px;
  height: 48px;
  background: #f1f5f9;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.stat-card-icon svg {
  width: 24px;
  height: 24px;
  color: #6366f1;
}
.stat-card-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.stat-label {
  font-size: 11px;
  color: #94a3b8;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.stat-number {
  font-size: 14px;
  font-weight: 600;
  color: #1e293b;
}

/* Content grid */
.content-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}
.left-column,
.right-column {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

/* Info cards */
.info-card {
  background: white;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.card-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 18px 24px;
  background: #fafcfc;
  border-bottom: 1px solid #e9edf2;
}
.card-header-icon {
  width: 32px;
  height: 32px;
  background: #f1f5f9;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.card-header-icon svg {
  width: 16px;
  height: 16px;
  color: #6366f1;
}
.card-header h3 {
  font-size: 16px;
  font-weight: 600;
  color: #0f172a;
  margin: 0;
}
.info-list {
  padding: 20px 24px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.info-item {
  display: flex;
  align-items: center;
  gap: 14px;
}
.info-label {
  width: 130px;
  font-size: 13px;
  color: #64748b;
}
.info-value {
  flex: 1;
}
.info-value input,
.info-value select {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 13px;
  font-family: inherit;
  transition: all 0.2s;
}
.info-value input:focus,
.info-value select:focus {
  outline: none;
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.1);
}

/* Allowances card */
.allowances-card .allowances-content {
  padding: 20px 24px;
}
.allowance-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
}
.allowance-item input {
  width: 150px;
  padding: 6px 10px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  text-align: right;
}
.allowance-divider {
  height: 1px;
  background: #eef2ff;
  margin: 8px 0;
}
.allowance-item.total .allowance-value {
  color: #f59e0b;
  font-size: 16px;
  font-weight: 700;
}
.allowance-item.gross .allowance-value {
  color: #10b981;
  font-size: 18px;
  font-weight: 700;
}

/* Spouse layout */
.spouse-layout {
  display: flex;
  gap: 20px;
  padding: 20px;
  align-items: flex-start;
}
.spouse-avatar {
  flex-shrink: 0;
  width: 90px;
  height: 90px;
  cursor: pointer;
}
.spouse-avatar img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #e2e8f0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
.spouse-avatar-placeholder {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: linear-gradient(135deg, #6366f1, #4f46e5);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 36px;
  font-weight: 600;
  color: white;
  border: 3px solid #e2e8f0;
}
.spouse-info {
  flex: 1;
}
.spouse-name {
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 12px;
}
.spouse-detail {
  font-size: 13px;
  color: #475569;
  margin-bottom: 8px;
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: 8px;
}
.spouse-detail span {
  font-weight: 600;
  color: #64748b;
  min-width: 130px;
}

/* Children list */
.children-list {
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.child-card {
  display: flex;
  gap: 16px;
  background: #f8fafc;
  border-radius: 14px;
  padding: 16px;
  border: 1px solid #eef2ff;
  position: relative;
}
.child-avatar {
  flex-shrink: 0;
  width: 70px;
  height: 70px;
  cursor: pointer;
}
.child-avatar img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid white;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
.avatar-placeholder {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  font-weight: 600;
  color: white;
  border: 3px solid white;
}
.child-info {
  flex: 1;
}
.child-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  flex-wrap: wrap;
  gap: 8px;
}
.child-name {
  font-size: 16px;
  font-weight: 600;
  color: #1e293b;
}
.child-age {
  font-size: 12px;
  color: #10b981;
  background: #d1fae5;
  padding: 2px 10px;
  border-radius: 20px;
}
.child-details {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.child-label {
  font-weight: 500;
  color: #64748b;
  min-width: 110px;
  display: inline-block;
  font-size: 12px;
}
.child-documents {
  margin-top: 8px;
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  align-items: center;
}

/* Parents container */
.parents-container {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 16px 20px;
}
.parent-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 14px 16px;
  background: #f8fafc;
  border-radius: 14px;
  border: 1px solid #eef2ff;
}
.parent-icon {
  font-size: 42px;
  flex-shrink: 0;
}
.parent-details {
  flex: 1;
}
.parent-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: center;
  margin-top: 6px;
}
.parent-job {
  font-size: 12px;
  color: #6366f1;
  background: #eef2ff;
  padding: 3px 10px;
  border-radius: 20px;
}
.parent-income {
  font-size: 13px;
  font-weight: 600;
  color: #10b981;
}

/* Support section */
.support-section {
  padding: 12px 20px 20px;
  border-top: 1px solid #eef2ff;
}
.support-title {
  font-size: 13px;
  font-weight: 600;
  color: #6366f1;
  margin-bottom: 12px;
}

/* Education, Training, Work, Guarantee lists */
.education-list,
.training-list,
.work-list,
.guarantee-list {
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.education-item,
.training-item,
.work-item,
.guarantor-card-item {
  background: #f8fafc;
  border-radius: 12px;
  padding: 14px;
  border: 1px solid #eef2ff;
}
.edu-header,
.training-header,
.work-header,
.guarantor-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  flex-wrap: wrap;
  gap: 8px;
}

/* Health & Legal */
.health-legal-content {
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.health-section h4,
.legal-section h4 {
  font-size: 13px;
  color: #6366f1;
  margin: 0 0 8px 0;
}

/* Language skills */
.skills-list {
  padding: 12px 20px;
}
.skill-tag {
  display: inline-block;
  background: #eef2ff;
  color: #6366f1;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  margin: 4px;
}
.other-skills {
  padding: 12px 20px 20px;
  border-top: 1px solid #eef2ff;
  font-size: 13px;
}

/* Compensation history */
.history-card.full-width {
  background: white;
  border-radius: 20px;
  overflow: hidden;
  margin-top: 32px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
}
.history-content-full {
  padding: 24px;
}
.history-timeline-full {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.timeline-entry {
  display: flex;
  gap: 20px;
  background: #f8fafc;
  border-radius: 16px;
  padding: 20px;
  border: 1px solid #eef2ff;
}
.timeline-left {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  min-width: 80px;
}
.timeline-date-badge {
  text-align: center;
  background: white;
  padding: 8px 12px;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
  min-width: 70px;
}
.timeline-date-day {
  font-size: 20px;
  font-weight: 700;
  color: #1e293b;
}
.timeline-date-month {
  font-size: 10px;
  font-weight: 600;
  color: #6366f1;
  text-transform: uppercase;
}
.timeline-date-year {
  font-size: 10px;
  color: #94a3b8;
}
.timeline-arrow {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.timeline-arrow.increase {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
}
.timeline-arrow.decrease {
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
}
.arrow-icon {
  font-size: 18px;
  font-weight: bold;
  color: white;
}
.timeline-body {
  flex: 1;
}
.timeline-values-full {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-wrap: wrap;
  background: white;
  padding: 14px 18px;
  border-radius: 14px;
  margin-bottom: 12px;
}
.value-card {
  flex: 1;
  min-width: 120px;
}
.value-label {
  font-size: 10px;
  color: #94a3b8;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 4px;
  display: block;
}
.value-amount {
  font-size: 18px;
  font-weight: 700;
  color: #1e293b;
}
.value-card.old .value-amount {
  color: #64748b;
  text-decoration: line-through;
}
.value-card.new.increase .value-amount {
  color: #10b981;
}
.value-card.new.decrease .value-amount {
  color: #ef4444;
}
.value-diff {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 14px;
  border-radius: 30px;
  font-size: 14px;
  font-weight: 600;
}
.value-diff.increase {
  background: #d1fae5;
  color: #059669;
}
.value-diff.decrease {
  background: #fee2e2;
  color: #dc2626;
}
.timeline-reason-full {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  background: #f1f5f9;
  padding: 12px 16px;
  border-radius: 12px;
  font-size: 13px;
  color: #475569;
}

/* Empty state */
.empty-state {
  text-align: center;
  padding: 60px;
  background: white;
  border-radius: 24px;
}
.empty-state svg {
  width: 64px;
  height: 64px;
  color: #cbd5e1;
  margin-bottom: 20px;
}
.empty-state h3 {
  font-size: 18px;
  color: #1e293b;
  margin-bottom: 12px;
}

/* ========== SCANNED DOCUMENTS STYLES ========== */
.scanned-documents-card .scanned-documents-content {
  padding: 20px 24px;
}

.scanned-documents-card .section-description {
  font-size: 13px;
  color: #64748b;
  margin: 0 0 16px 0;
  line-height: 1.5;
}

.documents-grid {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 12px;
  margin-bottom: 12px;
}

.document-upload-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 16px 12px;
  background: #f8fafc;
  border-radius: 10px;
  border: 1px solid #eef2ff;
  transition: all 0.2s;
  text-align: center;
}

.document-upload-item:hover {
  background: #f1f5f9;
  border-color: #e2e8f0;
}

.document-upload-item.has-file {
  background: #f0fdf4;
  border-color: #bbf7d0;
}

.document-upload-item.has-file:hover {
  background: #dcfce7;
}

.document-upload-item.custom-doc {
  border-style: dashed;
}

.doc-icon {
  font-size: 28px;
  flex-shrink: 0;
}

.doc-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  width: 100%;
}

.doc-label {
  font-size: 13px;
  font-weight: 500;
  color: #1e293b;
}

.doc-label-group {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.doc-name-input {
  width: 100%;
  padding: 4px 8px;
  border: none;
  border-bottom: 1px solid #e2e8f0;
  background: transparent;
  font-size: 12px;
  color: #1e293b;
  text-align: center;
}

.doc-name-input:focus {
  outline: none;
  border-bottom-color: #6366f1;
}

.doc-name-input::placeholder {
  color: #94a3b8;
  font-size: 11px;
}

.doc-status {
  font-size: 11px;
  color: #94a3b8;
}

.document-upload-item.has-file .doc-status {
  color: #10b981;
}

.doc-actions {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  width: 100%;
  flex-wrap: wrap;
}

.upload-btn {
  width: 32px;
  height: 32px;
  border: none;
  border-radius: 8px;
  background: #eef2ff;
  color: #6366f1;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
  padding: 0;
}

.upload-btn:hover {
  background: #e0e7ff;
  transform: scale(1.05);
}

.upload-btn svg {
  width: 16px;
  height: 16px;
}

.document-upload-item.has-file .upload-btn {
  background: #d1fae5;
  color: #059669;
}

.document-upload-item.has-file .upload-btn:hover {
  background: #a7f3d0;
}

.view-link {
  font-size: 16px;
  text-decoration: none;
  color: #6366f1;
  padding: 4px;
  border-radius: 6px;
  transition: all 0.2s;
}

.view-link:hover {
  background: #eef2ff;
  transform: scale(1.1);
}

.remove-btn {
  width: 24px;
  height: 24px;
  border: none;
  border-radius: 6px;
  background: #fee2e2;
  color: #ef4444;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  transition: all 0.2s;
  padding: 0;
}

.remove-btn:hover {
  background: #fecaca;
  transform: scale(1.1);
}

.file-name {
  font-size: 10px;
  color: #64748b;
  max-width: 80px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.add-doc-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 10px;
  background: #f8fafc;
  border: 2px dashed #e2e8f0;
  border-radius: 10px;
  color: #6366f1;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 4px;
  width: 100%;
}

.add-doc-btn:hover {
  background: #f1f5f9;
  border-color: #cbd5e1;
}

.add-doc-btn svg {
  width: 16px;
  height: 16px;
}

.file-info-note {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 16px;
  padding: 10px 14px;
  background: #f8fafc;
  border-radius: 8px;
  border: 1px solid #eef2ff;
  color: #94a3b8;
  font-size: 12px;
}

.file-info-note svg {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  color: #94a3b8;
}

.doc-count-badge {
  margin-left: auto;
  font-size: 11px;
  background: #e2e8f0;
  padding: 2px 10px;
  border-radius: 20px;
  color: #475569;
}

/* Responsive */
@media (max-width: 900px) {
  .documents-grid {
    grid-template-columns: 1fr 1fr;
  }
  
  .stats-cards {
    grid-template-columns: repeat(2, 1fr);
  }
  .content-grid {
    grid-template-columns: 1fr;
  }
  .parents-edit-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 600px) {
  .documents-grid {
    grid-template-columns: 1fr;
  }
  
  .document-upload-item {
    flex-direction: row;
    text-align: left;
    padding: 12px 14px;
  }
  
  .doc-info {
    align-items: flex-start;
  }
  
  .doc-label-group {
    align-items: flex-start;
  }
  
  .doc-name-input {
    text-align: left;
  }
  
  .doc-actions {
    justify-content: flex-end;
    width: auto;
  }
  
  .file-name {
    max-width: 60px;
  }
}

@media (max-width: 768px) {
  .employee-edit {
    padding: 20px 16px;
  }
  .hero-section {
    flex-direction: column;
    text-align: center;
    gap: 24px;
  }
  .hero-left {
    flex-direction: column;
  }
  .hero-right {
    text-align: center;
  }
  .stats-cards {
    grid-template-columns: 1fr;
  }
  .info-item {
    flex-direction: column;
    align-items: flex-start;
  }
  .info-label {
    width: 100%;
  }
  .edit-name-container {
    flex-direction: column;
  }
  .name-input {
    width: 100%;
  }
  .spouse-layout {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  .child-card {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  .timeline-entry {
    flex-direction: column;
  }
  .timeline-left {
    flex-direction: row;
    width: 100%;
    justify-content: space-between;
  }
  .timeline-values-full {
    flex-direction: column;
  }
  .edit-name-container {
    flex-direction: column;
  }
  .name-input {
    width: 100%;
  }
}
</style>