// stores/itemRequestService.ts
import api from './interceptor';

// ================================================================
// TYPES
// ================================================================

export interface RequestItem {
  itemId: number;
  quantity: number;
  remark?: string;
}

export interface User {
  userId: number;
  id?: number;
  username: string;
  fullName?: string;
  full_name?: string;
  email: string;
  roleId?: number;
  role?: string;
  departmentId?: number;
  department?: string;
}

export interface Store {
  storeId: number;
  id?: number;
  code: string;
  name: string;
  location?: string;
  status: string;
}

export interface Item {
  itemId: number;
  id?: number;
  code: string;
  name: string;
  standardName?: string;
  brand?: string;
  model?: string;
  uomId?: number;
  uom?: {
    uomId: number;
    code: string;
    name: string;
  };
  specText?: string;
}

export interface Group {
  id: number;
  name: string;
  code: string;
  status: string;
}

export interface Department {
  department_id: number;
  id?: number;
  name: string;
  code: string;
  description?: string;
  status?: string;
}

// ================================================================
// NOTIFICATION TYPES
// ================================================================

export interface RequestNotification {
  id: number;
  request_id: number;
  group_id: number | null;
  department_id: number | null;
  store_id: number;
  approval_type?: 'group' | 'department';
  is_department_approval?: boolean;
  status: 'pending' | 'accepted' | 'rejected';
  rejected_reason: string | null;
  responded_by: number | null;
  responded_at: string | null;
  viewed_at: string | null;
  created_at: string;
  updated_at: string;
  group?: {
    id: number;
    name: string;
    code: string;
  };
  department?: {
    department_id: number;
    name: string;
    code: string;
  };
  respondedByUser?: {
    userId: number;
    username: string;
    fullName: string;
  };
}

export interface RequestNotificationSummary {
  total: number;
  accepted: number;
  rejected: number;
  pending: number;
  allAccepted: boolean;
  hasRejection: boolean;
  rejectionReasons: Array<{
    groupId: number;
    groupName: string;
    reason: string;
    respondedBy: string;
    respondedAt: string;
  }>;
}

export interface ItemRequest {
  notifications: any;
  requestId: number;
  id?: number;
  requestCode: string;
  askingStoreId: number;
  askingStore?: Store;
  supplyingStoreId: number;
  supplyingStore?: Store;
  requestedById?: number;
  requestedByUser?: User;
  requestedBy?: string;
  requestedDate: string;
  status: 'pending' | 'approved' | 'rejected' | 'finalized';
  items: RequestItem[];
  remark?: string;
  approvedAt?: string;
  finalizedAt?: string;
  createdAt?: string;
  updatedAt?: string;
  statusHistory?: {
    current: string;
    canEdit: boolean;
    canApprove: boolean;
    canReject: boolean;
    canFinalize: boolean;
  };
  canEdit?: boolean;
  canApprove?: boolean;
  canReject?: boolean;
  canFinalize?: boolean;
  isAsset?: boolean;
  departmentId?: number;
  department?: {
    id: number;
    name: string;
    code: string;
  };
}

export interface ItemRequestStats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  finalized: number;
  byStatus: Array<{
    status: string;
    count: number;
  }>;
}

export interface ValidationError {
  itemId: number;
  itemCode: string;
  itemName: string;
  requestedQuantity: number;
  error: string;
  message: string;
  groupsWithoutBalance?: Array<{
    groupId: number;
    groupName: string;
  }>;
  balanceDetails?: Array<{
    groupName: string;
    balance: number;
  }>;
  shortage?: number;
  uomCode?: string;
}

export interface ValidationErrorResponse {
  success: false;
  error: string;
  message: string;
  errors: ValidationError[];
  data?: {
    supplyingStoreId: number;
    supplyingStoreName: string;
    totalGroups: number;
    validatedItems: any[];
    failedItems: number;
  };
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: {
    requests: T[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  };
  message?: string;
  error?: string;
}

export interface SingleRequestResponse {
  success: boolean;
  data: ItemRequest;
  message?: string;
  error?: string;
  errors?: ValidationError[];
}

export interface StatsResponse {
  success: boolean;
  data: ItemRequestStats;
  message?: string;
  error?: string;
}

export interface CreateRequestData {
  askingStoreId: number;
  supplyingStoreId: number;
  items: {
    itemId: number;
    quantity: number;
    remark?: string;
  }[];
  requestedById?: number;
  requestedDate: string;
  status?: 'pending' | 'approved' | 'rejected';
  remark?: string;
  isAsset?: boolean;
}

export interface UpdateRequestData {
  askingStoreId?: number;
  supplyingStoreId?: number;
  items?: {
    itemId: number;
    quantity: number;
    remark?: string;
  }[];
  requestedById?: number;
  requestedDate?: string;
  remark?: string;
  isAsset?: boolean;
}

export interface ExportItemData {
  'Request Code': string;
  'Asking Store': string;
  'Supplying Store': string;
  'Requested By': string;
  'Requested By Email': string;
  'Requested Date': string;
  'Status': string;
  'Is Asset': string;
  'Items': string;
  'Remark': string;
}

// ================================================================
// GROUP NOTIFICATION RESPONSE TYPES
// ================================================================

export interface GroupNotificationsResponse {
  success: boolean;
  data?: {
    notifications: Array<{
      id: number;
      request_id: number;
      group_id: number | null;
      department_id: number | null;
      store_id: number;
      status: 'pending' | 'accepted' | 'rejected';
      rejected_reason: string | null;
      responded_by: number | null;
      responded_at: string | null;
      created_at: string;
      updated_at: string;
      request: ItemRequest;
      group?: Group;
      department?: {
        department_id: number;
        name: string;
        code: string;
      };
      store: Store;
      respondedByUser?: User;
    }>;
    summary: {
      total: number;
      pending: number;
      accepted: number;
      rejected: number;
    };
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
    store: {
      id: number;
      group: { id: number };
    };
  };
  error?: string;
}

// ================================================================
// ITEM REQUEST SERVICE
// ================================================================

class ItemRequestService {
  // ================================================================
  // STORE METHODS (for dropdowns)
  // ================================================================

  /**
   * Get active stores for dropdown
   * GET /api/item-requests/active-stores
   */
  async getActiveStores(): Promise<{
    success: boolean;
    data: Store[];
    error?: string;
  }> {
    try {
      const response = await api.get('/item-requests/active-stores');
      return response.data;
    } catch (error: any) {
      console.error('Get active stores error:', error);
      return {
        success: false,
        data: [],
        error: error.response?.data?.error || 'Failed to fetch active stores'
      };
    }
  }

  /**
   * Get active items for dropdown
   * GET /api/item-requests/active-items
   */
  async getActiveItems(): Promise<{
    success: boolean;
    data: Item[];
    error?: string;
  }> {
    try {
      const response = await api.get('/item-requests/active-items');
      return response.data;
    } catch (error: any) {
      console.error('Get active items error:', error);
      return {
        success: false,
        data: [],
        error: error.response?.data?.error || 'Failed to fetch active items'
      };
    }
  }

  // ================================================================
  // STORE GROUPS METHOD
  // ================================================================

  /**
   * Get all active groups for a specific store
   * GET /api/item-requests/stores/:storeId/groups
   */
  async getStoreGroups(storeId: number): Promise<{
    success: boolean;
    data: Group[];
    error?: string;
  }> {
    try {
      const response = await api.get(`/item-requests/stores/${storeId}/groups`);
      return response.data;
    } catch (error: any) {
      console.error('Get store groups error:', error);
      return {
        success: false,
        data: [],
        error: error.response?.data?.error || 'Failed to fetch store groups'
      };
    }
  }

  // ================================================================
  // REQUEST METHODS
  // ================================================================

  /**
   * Get all item requests with pagination and filters
   * GET /api/item-requests
   */
  async getRequests(params: {
    page?: number;
    limit?: number;
    search?: string;
    status?: 'pending' | 'approved' | 'rejected' | 'finalized' | 'all';
    storeId?: number;
    userId?: number;
    sortBy?: string;
    sortOrder?: 'ASC' | 'DESC';
  } = {}): Promise<PaginatedResponse<ItemRequest>> {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.page) queryParams.append('page', params.page.toString());
      if (params.limit) queryParams.append('limit', params.limit.toString());
      if (params.search) queryParams.append('search', params.search);
      if (params.status) queryParams.append('status', params.status);
      if (params.storeId) queryParams.append('storeId', params.storeId.toString());
      if (params.userId) queryParams.append('userId', params.userId.toString());
      if (params.sortBy) queryParams.append('sortBy', params.sortBy);
      if (params.sortOrder) queryParams.append('sortOrder', params.sortOrder);

      const url = queryParams.toString() 
        ? `/item-requests?${queryParams.toString()}`
        : '/item-requests';

      const response = await api.get(url);
      return response.data;
    } catch (error: any) {
      console.error('Get requests error:', error);
      return {
        success: false,
        data: {
          requests: [],
          pagination: {
            page: 1,
            limit: 10,
            total: 0,
            pages: 0
          }
        },
        error: error.response?.data?.error || 'Failed to fetch requests'
      };
    }
  }

  /**
   * Get single item request by ID
   * GET /api/item-requests/:id
   */
  async getRequestById(id: number | string): Promise<SingleRequestResponse> {
    try {
      const response = await api.get(`/item-requests/${id}`);
      return response.data;
    } catch (error: any) {
      console.error('Get request by ID error:', error);
      return {
        success: false,
        data: {} as ItemRequest,
        error: error.response?.data?.error || 'Failed to fetch request'
      };
    }
  }

  /**
   * Get current user's requests
   * GET /api/item-requests/my-requests
   */
  async getMyRequests(params: {
    page?: number;
    limit?: number;
    status?: 'pending' | 'approved' | 'rejected' | 'finalized' | 'all';
  } = {}): Promise<PaginatedResponse<ItemRequest>> {
    try {
      const queryParams = new URLSearchParams();
      
      if (params.page) queryParams.append('page', params.page.toString());
      if (params.limit) queryParams.append('limit', params.limit.toString());
      if (params.status) queryParams.append('status', params.status);

      const url = queryParams.toString() 
        ? `/item-requests/my-requests?${queryParams.toString()}`
        : '/item-requests/my-requests';

      const response = await api.get(url);
      return response.data;
    } catch (error: any) {
      console.error('Get my requests error:', error);
      return {
        success: false,
        data: {
          requests: [],
          pagination: {
            page: 1,
            limit: 10,
            total: 0,
            pages: 0
          }
        },
        error: error.response?.data?.error || 'Failed to fetch your requests'
      };
    }
  }

  /**
   * Get requests by user ID
   * GET /api/item-requests/user/:userId
   */
  async getRequestsByUser(userId: number | string): Promise<{
    success: boolean;
    data: ItemRequest[];
    error?: string;
  }> {
    try {
      const response = await api.get(`/item-requests/user/${userId}`);
      return response.data;
    } catch (error: any) {
      console.error('Get requests by user error:', error);
      return {
        success: false,
        data: [],
        error: error.response?.data?.error || 'Failed to fetch requests for user'
      };
    }
  }

  /**
   * Get requests by status
   * GET /api/item-requests/status/:status
   */
  async getRequestsByStatus(status: 'pending' | 'approved' | 'rejected' | 'finalized'): Promise<{
    success: boolean;
    data: ItemRequest[];
    error?: string;
  }> {
    try {
      const response = await api.get(`/item-requests/status/${status}`);
      return response.data;
    } catch (error: any) {
      console.error('Get requests by status error:', error);
      return {
        success: false,
        data: [],
        error: error.response?.data?.error || 'Failed to fetch requests by status'
      };
    }
  }

  /**
   * Get requests by date range
   * GET /api/item-requests/date-range
   */
  async getRequestsByDateRange(startDate: string, endDate: string): Promise<{
    success: boolean;
    data: ItemRequest[];
    error?: string;
  }> {
    try {
      const response = await api.get(`/item-requests/date-range?startDate=${startDate}&endDate=${endDate}`);
      return response.data;
    } catch (error: any) {
      console.error('Get requests by date range error:', error);
      return {
        success: false,
        data: [],
        error: error.response?.data?.error || 'Failed to fetch requests by date range'
      };
    }
  }

  /**
   * Get request statistics
   * GET /api/item-requests/stats
   */
  async getStats(): Promise<StatsResponse> {
    try {
      const response = await api.get('/item-requests/stats');
      return response.data;
    } catch (error: any) {
      console.error('Get stats error:', error);
      return {
        success: false,
        data: {
          total: 0,
          pending: 0,
          approved: 0,
          rejected: 0,
          finalized: 0,
          byStatus: []
        },
        error: error.response?.data?.error || 'Failed to fetch statistics'
      };
    }
  }

  /**
   * Create a new item request
   * POST /api/item-requests
   */
  async createRequest(data: CreateRequestData): Promise<SingleRequestResponse> {
    try {
      const response = await api.post('/item-requests', data);
      return response.data;
    } catch (error: any) {
      console.error('Create request error:', error);
      
      const errorData = error.response?.data;
      
      if (errorData && errorData.errors && errorData.errors.length > 0) {
        return errorData as SingleRequestResponse;
      }
      
      return {
        success: false,
        data: {} as ItemRequest,
        error: error.response?.data?.error || error.response?.data?.message || 'Failed to create request'
      };
    }
  }

  /**
   * Update an existing item request
   * PUT /api/item-requests/:id
   */
  async updateRequest(id: number | string, data: UpdateRequestData): Promise<SingleRequestResponse> {
    try {
      const response = await api.put(`/item-requests/${id}`, data);
      return response.data;
    } catch (error: any) {
      console.error('Update request error:', error);
      
      const errorData = error.response?.data;
      
      if (errorData && errorData.errors && errorData.errors.length > 0) {
        return errorData as SingleRequestResponse;
      }
      
      return {
        success: false,
        data: {} as ItemRequest,
        error: error.response?.data?.error || error.response?.data?.message || 'Failed to update request'
      };
    }
  }

  /**
   * Update request status
   * PATCH /api/item-requests/:id/status
   */
  async updateStatus(id: number | string, status: 'pending' | 'approved' | 'rejected' | 'finalized'): Promise<{
    success: boolean;
    message: string;
    data?: ItemRequest;
    error?: string;
  }> {
    try {
      const response = await api.patch(`/item-requests/${id}/status`, { status });
      return response.data;
    } catch (error: any) {
      console.error('Update status error:', error);
      return {
        success: false,
        message: '',
        error: error.response?.data?.error || 'Failed to update status'
      };
    }
  }

  /**
   * Approve a request
   * PATCH /api/item-requests/:id/status
   */
  async approveRequest(id: number | string): Promise<{
    success: boolean;
    message: string;
    data?: ItemRequest;
    error?: string;
  }> {
    return this.updateStatus(id, 'approved');
  }

  /**
   * Reject a request
   * PATCH /api/item-requests/:id/status
   */
  async rejectRequest(id: number | string): Promise<{
    success: boolean;
    message: string;
    data?: ItemRequest;
    error?: string;
  }> {
    return this.updateStatus(id, 'rejected');
  }

  /**
   * Finalize a request
   * PATCH /api/item-requests/:id/status
   */
  async finalizeRequest(id: number | string): Promise<{
    success: boolean;
    message: string;
    data?: ItemRequest;
    error?: string;
  }> {
    return this.updateStatus(id, 'finalized');
  }

  /**
   * Delete a request (only pending or rejected)
   * DELETE /api/item-requests/:id
   */
  async deleteRequest(id: number | string): Promise<{
    success: boolean;
    message: string;
    error?: string;
  }> {
    try {
      const response = await api.delete(`/item-requests/${id}`);
      return response.data;
    } catch (error: any) {
      console.error('Delete request error:', error);
      return {
        success: false,
        message: '',
        error: error.response?.data?.error || 'Failed to delete request'
      };
    }
  }

  /**
   * Export requests to CSV data
   * GET /api/item-requests/export
   */
  async exportRequests(params?: {
    status?: 'pending' | 'approved' | 'rejected' | 'finalized' | 'all';
    storeId?: number;
    userId?: number;
  }): Promise<{
    success: boolean;
    data: ExportItemData[];
    total: number;
    error?: string;
  }> {
    try {
      const queryParams = new URLSearchParams();
      if (params?.status) queryParams.append('status', params.status);
      if (params?.storeId) queryParams.append('storeId', params.storeId.toString());
      if (params?.userId) queryParams.append('userId', params.userId.toString());

      const url = queryParams.toString() 
        ? `/item-requests/export?${queryParams.toString()}`
        : '/item-requests/export';

      const response = await api.get(url);
      return response.data;
    } catch (error: any) {
      console.error('Export requests error:', error);
      return {
        success: false,
        data: [],
        total: 0,
        error: error.response?.data?.error || 'Failed to export requests'
      };
    }
  }

  // ================================================================
  // GROUP NOTIFICATION METHODS
  // ================================================================

  /**
   * Get notifications for a specific group in a specific store
   * GET /api/item-requests/notifications/:storeId/:groupId
   * 
   * @param storeId - The ID of the store
   * @param groupId - The ID of the group
   * @param params - Optional pagination and status filters
   */
  async getGroupNotifications(
    storeId: number, 
    groupId: number,
    params?: {
      page?: number;
      limit?: number;
      status?: 'pending' | 'accepted' | 'rejected' | 'all';
    }
  ): Promise<GroupNotificationsResponse> {
    try {
      const queryParams = new URLSearchParams();
      if (params?.page) queryParams.append('page', params.page.toString());
      if (params?.limit) queryParams.append('limit', params.limit.toString());
      if (params?.status) queryParams.append('status', params.status);
      
      const url = queryParams.toString() 
        ? `/item-requests/notifications/${storeId}/${groupId}?${queryParams.toString()}`
        : `/item-requests/notifications/${storeId}/${groupId}`;
      
      const response = await api.get(url);
      return response.data;
    } catch (error: any) {
      console.error('Get group notifications error:', error);
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to get group notifications'
      };
    }
  }

  // ================================================================
  // DEPARTMENT NOTIFICATIONS (for ASSET requests)
  // ================================================================

  /**
   * Get notifications for a specific department (ASSET requests only)
   * GET /api/item-requests/notifications/department/:departmentId
   * 
   * @param departmentId - The ID of the department
   * @param params - Optional pagination and status filters
   */
  async getDepartmentNotifications(
    departmentId: number,
    params?: {
      page?: number;
      limit?: number;
      status?: 'pending' | 'accepted' | 'rejected' | 'all';
    }
  ): Promise<{
    success: boolean;
    data?: {
      notifications: Array<{
        id: number;
        request_id: number;
        department_id: number;
        store_id: number;
        status: 'pending' | 'accepted' | 'rejected';
        rejected_reason: string | null;
        responded_by: number | null;
        responded_at: string | null;
        created_at: string;
        updated_at: string;
        request: ItemRequest;
        department: {
          department_id: number;
          name: string;
          code: string;
          description?: string;
        };
        respondedByUser?: User;
      }>;
      summary: {
        total: number;
        pending: number;
        accepted: number;
        rejected: number;
      };
      pagination: {
        page: number;
        limit: number;
        total: number;
        pages: number;
      };
      department: {
        id: number;
        name: string;
        code: string;
      };
    };
    error?: string;
  }> {
    try {
      // Validate departmentId
      if (!departmentId || isNaN(departmentId) || departmentId <= 0) {
        return {
          success: false,
          error: 'Invalid department ID'
        };
      }

      const queryParams = new URLSearchParams();
      if (params?.page) queryParams.append('page', params.page.toString());
      if (params?.limit) queryParams.append('limit', params.limit.toString());
      if (params?.status) queryParams.append('status', params.status);
      
      const url = queryParams.toString() 
        ? `/item-requests/notifications/department/${departmentId}?${queryParams.toString()}`
        : `/item-requests/notifications/department/${departmentId}`;
      
      console.log('📤 Fetching department notifications:', url);
      
      const response = await api.get(url);
      console.log('📥 Department notifications response:', response.data);
      return response.data;
    } catch (error: any) {
      console.error('❌ Get department notifications error:', error);
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to get department notifications'
      };
    }
  }

  // ================================================================
  // 🔥 PENDING NOTIFICATIONS (Combined - Group + Department)
  // ================================================================

  /**
   * Get all pending notifications for the current user (Group + Department)
   * GET /api/item-requests/notifications/pending
   * 
   * @param params - Optional pagination filters
   */
  async getPendingNotifications(params?: {
    page?: number;
    limit?: number;
  }): Promise<{
    success: boolean;
    data?: {
      notifications: Array<{
        id: number;
        request_id: number;
        group_id: number | null;
        department_id: number | null;
        store_id: number;
        approval_type: 'group' | 'department';
        is_department_approval: boolean;
        status: 'pending' | 'accepted' | 'rejected';
        rejected_reason: string | null;
        responded_by: number | null;
        responded_at: string | null;
        viewed_at: string | null;
        created_at: string;
        updated_at: string;
        request: ItemRequest;
        group?: {
          id: number;
          name: string;
          code: string;
        };
        department?: {
          department_id: number;
          name: string;
          code: string;
        };
        store?: Store;
        respondedByUser?: User;
        _type?: 'group' | 'department';
        _typeLabel?: string;
      }>;
      summary: {
        total: number;
        group: number;
        department: number;
        page: number;
        limit: number;
        pages: number;
      };
      user: {
        userId: number;
        role: string;
        storeId: number | null;
        groupId: number | null;
        departmentId: number | null;
      };
    };
    error?: string;
  }> {
    try {
      const queryParams = new URLSearchParams();
      if (params?.page) queryParams.append('page', params.page.toString());
      if (params?.limit) queryParams.append('limit', params.limit.toString());
      
      const url = queryParams.toString() 
        ? `/item-requests/notifications/pending?${queryParams.toString()}`
        : '/item-requests/notifications/pending';
      
      console.log('📤 Fetching pending notifications:', url);
      
      const response = await api.get(url);
      console.log('📥 Pending notifications response:', response.data);
      return response.data;
    } catch (error: any) {
      console.error('❌ Get pending notifications error:', error);
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to get pending notifications'
      };
    }
  }

  // ================================================================
  // OTHER NOTIFICATION METHODS
  // ================================================================

  /**
   * Get request with notification status and group responses
   * GET /api/item-requests/:id/notifications
   * 
   * @param id - The request ID
   */
  async getRequestWithNotifications(id: number | string): Promise<{
    success: boolean;
    data?: {
      request: ItemRequest;
      notificationSummary: RequestNotificationSummary;
    };
    error?: string;
  }> {
    try {
      const response = await api.get(`/item-requests/${id}/notifications`);
      return response.data;
    } catch (error: any) {
      console.error('Get request with notifications error:', error);
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to fetch request notifications'
      };
    }
  }

  /**
   * Check if all groups have accepted/rejected the request
   * GET /api/item-requests/:id/notifications/status
   * 
   * @param requestId - The request ID
   */
  async checkRequestNotificationStatus(requestId: number): Promise<{
    success: boolean;
    data?: {
      allAccepted: boolean;
      hasRejection: boolean;
      total: number;
      acceptedCount: number;
      rejectedCount: number;
      pendingCount: number;
    };
    error?: string;
  }> {
    try {
      const response = await api.get(`/item-requests/${requestId}/notifications/status`);
      return response.data;
    } catch (error: any) {
      console.error('Check notification status error:', error);
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to check notification status'
      };
    }
  }

  /**
   * Get all rejection reasons for a request
   * GET /api/item-requests/notifications/requests/:requestId/rejections
   * 
   * @param requestId - The request ID
   */
  async getRejectionReasons(requestId: number): Promise<{
    success: boolean;
    data?: Array<{
      groupId: number;
      groupName: string;
      reason: string;
      respondedBy: string;
      respondedAt: string;
    }>;
    error?: string;
  }> {
    try {
      const response = await api.get(`/item-requests/notifications/requests/${requestId}/rejections`);
      return response.data;
    } catch (error: any) {
      console.error('Get rejection reasons error:', error);
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to get rejection reasons'
      };
    }
  }

  /**
   * Accept a notification (group or department accepts the request)
   * POST /api/item-requests/notifications/:notificationId/accept
   * 
   * @param notificationId - The notification ID
   */
  async acceptNotification(notificationId: number): Promise<{
    success: boolean;
    message?: string;
    data?: RequestNotification;
    error?: string;
  }> {
    try {
      const response = await api.post(`/item-requests/notifications/${notificationId}/accept`);
      return response.data;
    } catch (error: any) {
      console.error('Accept notification error:', error);
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to accept notification'
      };
    }
  }

  /**
   * Reject a notification with reason
   * POST /api/item-requests/notifications/:notificationId/reject
   * 
   * @param notificationId - The notification ID
   * @param reason - The rejection reason
   */
  async rejectNotification(notificationId: number, reason: string): Promise<{
    success: boolean;
    message?: string;
    data?: RequestNotification;
    error?: string;
  }> {
    try {
      const response = await api.post(`/item-requests/notifications/${notificationId}/reject`, { reason });
      return response.data;
    } catch (error: any) {
      console.error('Reject notification error:', error);
      return {
        success: false,
        error: error.response?.data?.error || 'Failed to reject notification'
      };
    }
  }

  // ================================================================
  // NOTIFICATION HELPER METHODS
  // ================================================================

  /**
   * Check if a request can be approved (all groups and department accepted)
   */
  canApproveRequest(request: ItemRequest): boolean {
    if (!request || request.status !== 'pending') return false;
    
    const notifications = (request as any).notifications || [];
    if (notifications.length === 0) return false;
    
    const allAccepted = notifications.every((n: any) => n.status === 'accepted');
    const hasRejection = notifications.some((n: any) => n.status === 'rejected');
    
    return allAccepted && !hasRejection;
  }

  /**
   * Check if a request can be printed
   */
  canPrintRequest(request: ItemRequest): boolean {
    return this.canApproveRequest(request);
  }

  /**
   * Get acceptance summary for display
   */
  getAcceptanceSummary(request: ItemRequest): string {
    const notifications = (request as any).notifications || [];
    if (notifications.length === 0) return 'No approvals';
    
    const total = notifications.length;
    const accepted = notifications.filter((n: any) => n.status === 'accepted').length;
    const rejected = notifications.filter((n: any) => n.status === 'rejected').length;
    const pending = notifications.filter((n: any) => n.status === 'pending').length;
    
    if (rejected > 0) return `❌ ${rejected} rejected`;
    if (accepted === total) return `✅ All ${total} accepted`;
    return `⏳ ${accepted}/${total} accepted`;
  }

  /**
   * Get tooltip for approve button
   */
  getApproveTooltip(request: ItemRequest): string {
    if (!request || request.status !== 'pending') return 'Request is not pending';
    
    const notifications = (request as any).notifications || [];
    const hasRejection = notifications.some((n: any) => n.status === 'rejected');
    if (hasRejection) return 'Some have rejected this request. Edit and resubmit.';
    
    const allAccepted = notifications.every((n: any) => n.status === 'accepted');
    if (!allAccepted) return 'Waiting for all approvals';
    
    return 'All approved - Click to proceed';
  }

  /**
   * Get group acceptance status for display
   */
  getGroupStatusDisplay(request: ItemRequest): {
    total: number;
    accepted: number;
    rejected: number;
    pending: number;
    allAccepted: boolean;
    hasRejection: boolean;
    progress: number;
  } {
    const notifications = (request as any).notifications || [];
    const total = notifications.length;
    const accepted = notifications.filter((n: any) => n.status === 'accepted').length;
    const rejected = notifications.filter((n: any) => n.status === 'rejected').length;
    const pending = notifications.filter((n: any) => n.status === 'pending').length;
    const allAccepted = total > 0 && accepted === total;
    const hasRejection = rejected > 0;
    const progress = total > 0 ? (accepted / total) * 100 : 0;

    return {
      total,
      accepted,
      rejected,
      pending,
      allAccepted,
      hasRejection,
      progress
    };
  }

  // ================================================================
  // HELPER METHODS
  // ================================================================

  /**
   * Get user display name from request
   */
  getRequesterName(request: ItemRequest): string {
    if (request?.requestedByUser) {
      return request.requestedByUser.fullName || 
             request.requestedByUser.full_name || 
             request.requestedByUser.username || 
             'Unknown User';
    }
    return request?.requestedBy || 'Unknown User';
  }

  /**
   * Get user email from request
   */
  getRequesterEmail(request: ItemRequest): string {
    return request?.requestedByUser?.email || 'N/A';
  }

  /**
   * Check if user can perform action on request
   */
  canPerformAction(request: ItemRequest, action: 'edit' | 'approve' | 'reject' | 'finalize'): boolean {
    if (!request) return false;
    
    const actions = {
      edit: request.status !== 'finalized',
      approve: request.status === 'pending',
      reject: request.status === 'pending',
      finalize: request.status === 'approved',
    };
    
    return actions[action] || false;
  }

  /**
   * Get available status options for a request
   */
  getAvailableStatuses(request: ItemRequest): Array<'pending' | 'approved' | 'rejected' | 'finalized'> {
    if (!request) return [];
    
    const statuses: Array<'pending' | 'approved' | 'rejected' | 'finalized'> = [];
    if (request.status === 'pending') {
      statuses.push('approved', 'rejected');
    } else if (request.status === 'approved') {
      statuses.push('finalized');
    }
    return statuses;
  }

  /**
   * Get status badge color
   */
  getStatusBadge(status: string): string {
    const badgeMap: Record<string, string> = {
      pending: 'warning',
      approved: 'success',
      rejected: 'danger',
      finalized: 'info',
    };
    return badgeMap[status] || 'secondary';
  }

  /**
   * Get status display name
   */
  getStatusDisplay(status: string): string {
    const displayMap: Record<string, string> = {
      pending: 'Pending',
      approved: 'Approved',
      rejected: 'Rejected',
      finalized: 'Finalized',
    };
    return displayMap[status] || status;
  }

  /**
   * Get status icon
   */
  getStatusIcon(status: string): string {
    const iconMap: Record<string, string> = {
      pending: '⏳',
      approved: '✅',
      rejected: '❌',
      finalized: '📋',
    };
    return iconMap[status] || '📦';
  }

  /**
   * Format date
   */
  formatDate(date: string | Date | null): string {
    if (!date) return 'N/A';
    const d = new Date(date);
    if (isNaN(d.getTime())) return 'N/A';
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  /**
   * Format date time
   */
  formatDateTime(date: string | Date | null): string {
    if (!date) return 'N/A';
    const d = new Date(date);
    if (isNaN(d.getTime())) return 'N/A';
    return d.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  /**
   * Get total quantity of items in request
   */
  getTotalQuantity(request: ItemRequest): number {
    if (!request || !request.items) return 0;
    return request.items.reduce((sum, item) => sum + (item.quantity || 0), 0);
  }

  /**
   * Get total number of items in request
   */
  getTotalItems(request: ItemRequest): number {
    return request?.items?.length || 0;
  }

  /**
   * Check if request is editable
   */
  isEditable(request: ItemRequest): boolean {
    return request?.status !== 'finalized';
  }

  /**
   * Check if request is pending
   */
  isPending(request: ItemRequest): boolean {
    return request?.status === 'pending';
  }

  /**
   * Check if request is approved
   */
  isApproved(request: ItemRequest): boolean {
    return request?.status === 'approved';
  }

  /**
   * Check if request is rejected
   */
  isRejected(request: ItemRequest): boolean {
    return request?.status === 'rejected';
  }

  /**
   * Check if request is finalized
   */
  isFinalized(request: ItemRequest): boolean {
    return request?.status === 'finalized';
  }

  /**
   * Check if request has all groups accepted
   */
  hasAllGroupsAccepted(request: ItemRequest): boolean {
    const notifications = (request as any).notifications || [];
    if (notifications.length === 0) return false;
    return notifications.every((n: any) => n.status === 'accepted');
  }

  /**
   * Check if request has any rejection
   */
  hasAnyRejection(request: ItemRequest): boolean {
    const notifications = (request as any).notifications || [];
    return notifications.some((n: any) => n.status === 'rejected');
  }

  /**
   * Get pending groups count
   */
  getPendingGroupsCount(request: ItemRequest): number {
    const notifications = (request as any).notifications || [];
    return notifications.filter((n: any) => n.status === 'pending').length;
  }

  /**
   * Check if request is an asset request
   */
  isAssetRequest(request: ItemRequest): boolean {
    return (request as any).isAsset === true;
  }

  /**
   * Get department name for asset request
   */
  getAssetDepartment(request: ItemRequest): string {
    const dept = (request as any).department;
    if (dept) {
      return dept.name || dept.code || 'N/A';
    }
    return 'N/A';
  }
}

export default new ItemRequestService();